import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Image;
import java.awt.Point;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.border.Border;
import javax.swing.border.LineBorder;
import javax.swing.BorderFactory;
import javax.swing.DropMode;
import java.awt.Dimension;
import java.awt.Component;
import java.awt.Font;
import javax.swing.JScrollBar;

public class pronouns {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void pronouns() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					pronouns window = new pronouns();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public pronouns() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame("Pronouns");
		frame.getContentPane().setBackground(new Color(175, 238, 238));
		frame.setBounds(100, 100, 700, 700);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setBounds(6, 6, 98, 80);
		Image img = new ImageIcon(this.getClass().getResource("/pp.png")).getImage();
		lblNewLabel_1.setIcon(new ImageIcon(img));
		frame.getContentPane().add(lblNewLabel_1);
		
		JLabel label = new JLabel("");
		label.setIgnoreRepaint(true);
		label.setBounds(6, 584, 98, 90);
		Image img1 = new ImageIcon(this.getClass().getResource("/pp.png")).getImage();
		label.setIcon(new ImageIcon(img1));
		frame.getContentPane().add(label);
		
		JLabel label_1 = new JLabel("");
		label_1.setBounds(613, 6, 81, 80);
		Image img2 = new ImageIcon(this.getClass().getResource("/pp.png")).getImage();
		label_1.setIcon(new ImageIcon(img2));
		frame.getContentPane().add(label_1);
		
		JLabel label_2 = new JLabel("");
		label_2.setBounds(619, 584, 75, 90);
		Image img3 = new ImageIcon(this.getClass().getResource("/pp.png")).getImage();
		label_2.setIcon(new ImageIcon(img3));
		frame.getContentPane().add(label_2);
		
	
	
		
		JTextArea txtrPronouns = new JTextArea();
		txtrPronouns.setEditable(false);
		txtrPronouns.setWrapStyleWord(true);
		txtrPronouns.setLineWrap(true);
		txtrPronouns.setFont(new Font("Lucida Grande", Font.PLAIN, 13));
		
		txtrPronouns.setDoubleBuffered(true);
		txtrPronouns.setBackground(new Color(175, 238, 238));
		txtrPronouns.setText("\tМысалы (For example):\n«John studies at Alash National University. He is one of the best students — Джон Алаш Ұлттық Университетінде оқиды. Ол — үздік студенттердің бірі.Өйткені ол сыныпқа жаңадан келді.» Жоғарыдағы мысалда екінші сөйлемдегі «ол» деген есім сөз (жіктеу есімдігі) алғашқы сөйлемдегі «Джон» сөзін алмастырып отыр.  In the following example, the name «John» was replaced by the personal pronoun «he».\n\nАғылшын тілінде есімдіктердің төмендегіше көптеген топтары мен түрлері бар:\n\n• жіктеу есімдігі (Personal Prn.) — I (мен), you (сен, сіз), he (ол — еркек), she (ол — әйел), it (ол — жануарлар, жансыз заттар), we (біз), they (олар);\n\n• тәуелдеу есімдігі (Possessive Prn.) — my (менің), your (сенің, сіздің, сіздердің), his (оның), her (оның), its (оның), our (біздің), their (олардың);\n\n• сілтеу есімдігі (Demonstrative Prn.) — this (мынау), that (анау), these (мыналар), those (аналар);\n\n• сұрау есімдігі (Interrogative Prn.) — who немесе whom (кім немсе кімге), what (не), whose (кімнің), which (қайсы);\n\n• белгісіздік есімдігі (Indefinite Prn) — some, any, (some мен any-дің туындылары: somebody (белгісіз біреу), anybody ( кез-келген біреу), somewhere (бір жерде), anywhere (кез-келген жерде), something (бірдеңе, бір нәрсе), anything (кез-келген бірдеңе), someone (біреу), anyone (к-к біреу), one (біреу, кей біреу);\n\n• қатыстық есімдігі (Relative Prn.) — who (те, кто немесе тот, кто (который)) немесе whom (которого не-се кого), what, which (который), whose (чья, чей), that (что не-се то, что);\n\nЕскерту! Қатыстық есімдіктердің қазақ тілінде тікелей аудармасы жоқ. Қатыстық есімдіктер мен сұрау есімдіктерінің жазылулары бірдей болғанымен, мағыналық айырмашылығы бар. Мыс: The man who \nwas here is our boss — Осында болған кісі — біздің бастығымыз. \n\n• өздік есімдігі (Reflexive Prn.) — myself (өзім), yourself (өзің), himself (өзі), herself (өзі), itself (өзі), oneself (өзі — белгісіз біреу), ourselves (өзіміз), yourselves (өздерің, өздеріңіз), themselves (өздері); \n\n• ортақтық (өзаралық) есімдігі (Reciprocal Prn.) — each other (бір-бірін — адамдар мен заттарға қатысты), one another (бір-бірін — екі немесе одан көп адамдарға және заттарға қатысты);\n\n• болымсыздық есімдігі (Negative Prn.) — no (… емес), none=no one (ешкім), neither (ешкім, ешбірі), nobody (ешкім), nothing (ештеңе), no one (ешкім).\n");
		txtrPronouns.setBounds(0, -15, 679, 689);
		frame.getContentPane().add(txtrPronouns);
		
		JScrollPane scrollPane = new JScrollPane(txtrPronouns, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		scrollPane.setToolTipText("");
		
		scrollPane.setBounds(10, 114, 684, 469);
		Border emptyBorder = BorderFactory.createEmptyBorder(0, 0, 0, 0);
		scrollPane.setBorder(emptyBorder);
		frame.getContentPane().add(scrollPane);
		

		
		JTextArea txtrPronouns_1 = new JTextArea();
		txtrPronouns_1.setEditable(false);
		txtrPronouns_1.setLineWrap(true);
		txtrPronouns_1.setWrapStyleWord(true);
		txtrPronouns_1.setBackground(new Color(175, 238, 238));
		txtrPronouns_1.setBounds(85,12,525,105);
		txtrPronouns_1.setText("\tЕсімдіктер (ағл.: Pronouns) — тұлғаға, затқа, заттың сынына және санына, үстеуге сілтеме жасап (олардың орындарын ауыстырып), бірақ оларды атамай, басқаша сөздермен (есім сөздермен) алмастыратын сөз табы. Есімдіктердің лексикалық мағынасы жоқ, сөйлемнің мағынасын өзгертпейді. Есімдіктер алдыңғы сөйлемде немесе ойда айтылған сөздердің орнын ауыстырады. ");
		frame.getContentPane().add(txtrPronouns_1);
		
	}

}
