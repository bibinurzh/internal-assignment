import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Image;
import java.awt.event.ActionEvent;

import javax.swing.AbstractAction;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.border.Border;

import com.sun.glass.ui.Timer;

public class prepositions {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void prepositions() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					prepositions window = new prepositions();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public prepositions() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame("Prepositions");
		frame.getContentPane().setBackground(new Color(175, 238, 238));
		frame.setBounds(100, 100, 700, 700);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setBounds(6, 6, 98, 80);
		Image img = new ImageIcon(this.getClass().getResource("/pp.png")).getImage();
		lblNewLabel_1.setIcon(new ImageIcon(img));
		frame.getContentPane().add(lblNewLabel_1);
		
		JLabel label = new JLabel("");
		label.setIgnoreRepaint(true);
		label.setBounds(6, 584, 98, 90);
		Image img1 = new ImageIcon(this.getClass().getResource("/pp.png")).getImage();
		label.setIcon(new ImageIcon(img1));
		frame.getContentPane().add(label);
		
		JLabel label_1 = new JLabel("");
		label_1.setBounds(613, 6, 81, 80);
		Image img2 = new ImageIcon(this.getClass().getResource("/pp.png")).getImage();
		label_1.setIcon(new ImageIcon(img2));
		frame.getContentPane().add(label_1);
		
		JLabel label_2 = new JLabel("");
		label_2.setBounds(619, 584, 75, 90);
		Image img3 = new ImageIcon(this.getClass().getResource("/pp.png")).getImage();
		label_2.setIcon(new ImageIcon(img3));
		frame.getContentPane().add(label_2);
		
		JTextArea txtrPreposition = new JTextArea();
		txtrPreposition.setBackground(new Color(175, 238, 238));
		txtrPreposition.setWrapStyleWord(true);
		txtrPreposition.setLineWrap(true);
		txtrPreposition.setText("■ in — уақытқа қатысты қолданылатын көмекші сөздердің бірі. Ол қазақ тіліндегі -да (-де, -та, -те), -ы (жыл-ы) дегендей жалғаулар сияқты сөйлемге мағына береді. Кей кездері оған лайықты қазақша жалғау да болмайды. Мысалы: in October – қазанда (ай), in 1932 – 1932 жылы, in two weeks – екі аптада, in the morning – таңертең, in 90s – 90-шы жылдары.\n\n■ on — уақытқа қатысты қолданылатын көмекші сөздердің бірі. Ол апта күндерімен, күндермен (даталармен) және, т.б. уақыттық сөздермен бірге қолданылады. Мысалы: on Sunday – жексенбіде, on september 11th. – 11-ші қыркүйекте.\n\n■ for — көп мақсатта (көп мағынада) қолданылатын көмекші сөз (шылау). Бұл сабақта for шылауының «үшін» деген мағынасын қарастырамыз. Ескертетіні, бұл шылау көп жағдайларға да қазақ тіліне тікелей аударылмайды. for — үшін, барыс септігі+ арналған. «Біреу үшін», «бір зат үшін» деген типтегі тіркестерде қолданылады. Мысалы: This present is for you — Мына сыйлық сіз үшін (сізге арналған). I go to the supermarket for a water — Мен су (алу) үшін супермаркетке барамын.\n\n■ about — туралы (жайлы). Бұл көмекші сөз де көп мақсатта (көп мағынада) қолданылады. Мысалы: We are talking about a new film — Біз жаңа фильм туралы әңгімелесіп отырмыз. What do you know about Abai? — Абай туралы не білесіз?\n\n■ of (off дегенмен шатастырмаңыз) — қазақ тіліндегі ілік септігі жалғауларының (-ның (нің), -тың (тің), -дың (дің)) мағынасын беретін көмекші сөз. Of шылауының сөзбе-сөз аудармасы жоқ. Мысалы: Citizens of Kazakhstan — Қазақстанның азаматтары. All of you — сіздердің барлықтарыңыз. \n\n■ between — арасында, екеуінің ортасында. Екі заттың (зат есім) арасында тұрған заттың орнын сипаттағанда осы between көмекші сөзін пайдаланамыз. Мысалы: Our house is between the hospital and the university — Біздің үйіміз аурухана мен университеттің арасында.\n\n■ opposite — қарама-қарсы бетте (жақта). Екі зат есімнің бір-бірлеріне бетпе-бет орыналасқанын сипаттау үшін қолданылады. Мысалы: Our university is oppsite the central library — Біздің университет орталық кітапхананың қарсы жағында (екеуі бетпе-бет орыналасқан).\n\n■ inside — ішінде, ішкі жағында. Бір заттың ішінде, ішкі жағында орыналасқан зат есімді сипаттаған қолданылады. Мысалы: Is there anything inside the box? — Қораптың ішінде не бар?\n\n■ outside — сыртында, сыртта. Бұның мағынасы inside-қа қарама-қарсы екені көрініп тұр. Мысалы: He is waiting outside — Ол сыртта күтіп тұр.\n\n■ among — арасында, ортасында. Топтың ішінде, заттардың (адамдардың) арасындағы зат есімді сипаттау үшін қолданылады. Мысалы: We like being among people — Біз адамдардың ортасында (арасында) болуды ұнатамыз.\n");
		txtrPreposition.setBounds(0, 0, 700, 678);
		txtrPreposition.setEditable(false);
		frame.getContentPane().add(txtrPreposition);
		
		JScrollPane scrollPane = new JScrollPane(txtrPreposition, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		scrollPane.setBounds(10, 111, 690, 461);
		frame.getContentPane().add(scrollPane);
		Border emptyBorder = BorderFactory.createEmptyBorder(0, 0, 0, 0);
		scrollPane.setBorder(emptyBorder);
		JTextArea txtrPreposition_1 = new JTextArea();
		txtrPreposition_1.setEditable(false);
		txtrPreposition_1.setWrapStyleWord(true);
		txtrPreposition_1.setLineWrap(true);
		txtrPreposition_1.setBackground(new Color(175, 238, 238));
		txtrPreposition_1.setText("\tPreposition — қазақ тілінде: көмекші сөз — сөйлемнің мүшесі болып, оның мағынасына өз үлесін қосатын, бірақ жеке тұрғанда ешқандай грамматикалық мағынасы жоқ сөз, көмекші сөз.\nГрамматикалық мағынасы болмағандықтан да олардың қазақ тіліндегі нақты аудармасы бола бермейді. Мысалы, on Sunday — жексенбіде (жексенбі күні), in box — қорапта (қораптың ішінде).\n");
		txtrPreposition_1.setBounds(86, 6, 533, 104);
		frame.getContentPane().add(txtrPreposition_1);
		
	
	}

}
