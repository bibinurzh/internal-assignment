import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;

public class helpFile {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void help() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					helpFile window = new helpFile();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public helpFile() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(new Color(175, 238, 238));
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel = new JLabel("<html>HOW TO PLAY?\n<br>1. Word Puzzle Game: Find one word that will suit to the given statement. The word can be found vertically, horizontally, diagonally, from right to left or from left to righ.\nAfter pressing the buttons with letter or typing it by yourself, press \"Submit\" button to check the answer. \n<br>2.  Fill In the Blank: Find the most suitable word. If the answer is right, the scroe is added. Otherwise, the score will be taken. In the end of the game the score will be displayed. <br>NOTE: it is possible to get the negative score, but do not worry you will have opportunity to improve.</html>");
		lblNewLabel.setBounds(6, 77, 588, 170);
		frame.getContentPane().add(lblNewLabel);
		frame.setBackground(new Color(175, 238, 238));
		frame.setBounds(100, 100, 600, 450);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		
		JLabel lblNewLabel_3 = new JLabel("");
		Image img5 = new ImageIcon(this.getClass().getResource("/pp.png")).getImage();
		lblNewLabel_3.setIcon(new ImageIcon(img5));
		lblNewLabel_3.setBounds(6, 6, 97, 85);
		frame.getContentPane().add(lblNewLabel_3);
		
		JLabel label12 = new JLabel("");
		Image img2 = new ImageIcon(this.getClass().getResource("/pp.png")).getImage();
		label12.setIcon(new ImageIcon(img2));
		label12.setBounds(6, 315, 97, 85);
		frame.getContentPane().add(label12);
		
		JLabel label_5 = new JLabel("");
		Image img3 = new ImageIcon(this.getClass().getResource("/pp.png")).getImage();
		label_5.setIcon(new ImageIcon(img3));
		label_5.setBounds(519, 315, 75, 85);
		frame.getContentPane().add(label_5);
		
		JLabel label_2 = new JLabel("");
		Image img4 = new ImageIcon(this.getClass().getResource("/pp.png")).getImage();
		label_2.setIcon(new ImageIcon(img4));
		label_2.setBounds(519, 6, 75, 85);
		frame.getContentPane().add(label_2);
		
		JLabel lblNewLabel_1 = new JLabel("<html> Hello, dear User! This is program \"Learn english with Bibinur\". The aim of it is to teach English based on the Kazakh language.</html>");
		lblNewLabel_1.setBounds(108, 6, 384, 85);
		frame.getContentPane().add(lblNewLabel_1);
		
		JLabel lblTheInformationAbout = new JLabel("<html> The information about English grammar was taken from the website \n<br> Tilder.Kz (http://tilder.kz/?paged=4&cat=12).\n<br>The restaurant picture \n<br>(https://www.pexels.com/search/restaurant/)\n<br>Kazakh ornament \n<br>(http://www.liveinternet.ru/users/len/post264839317/)\n<br> Dialogue \n<br>(http://everydayfeminism.com/2015/07/effective-dialogue-strategies/)\n<br> Word Search Puzzle\n<br> (http://www.istockphoto.com/vector/word-search-puzzle-with-sweets-gm517810618-89679177)\n< Fill In The Blank\n<br> (http://www.heartfeltleadership.com/blog/2013/6/3/forget-questions-fill-in-the-blanks.html)</html>\n");
		lblTheInformationAbout.setBounds(89, 230, 429, 192);
		frame.getContentPane().add(lblTheInformationAbout);
		JMenuBar menuBar = new JMenuBar();
		frame.setJMenuBar(menuBar);
		
		JMenu mnNewMenu = new JMenu("File");
		menuBar.add(mnNewMenu);
		
		
		JMenuItem mntmNewMenuItem = new JMenuItem("Exit");
		mntmNewMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(JFrame.EXIT_ON_CLOSE);
			}
		});
		

	
	JMenuItem mntmTheory = new JMenuItem("Go to Theory Page");
	mntmTheory.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			theoryPage theory=new theoryPage();
			theory.theory();
		}
	}
	);
	
	JMenuItem mntmGame = new JMenuItem("Go to Game Page");
	mntmGame.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			gamePage game=new gamePage();
			game.game();
		}
	});
	mnNewMenu.add(mntmGame);
	
	mnNewMenu.add(mntmTheory);
	mnNewMenu.add(mntmNewMenuItem);
	}
	
}
