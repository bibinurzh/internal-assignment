import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Image;

import javax.swing.ImageIcon;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.SwingConstants;
import javax.swing.border.EmptyBorder;
import javax.swing.event.AncestorEvent;
import javax.swing.event.AncestorListener;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import javax.swing.JButton;
import java.awt.Font;

public class blankPage {

	private JFrame frame;
	int scrores=0;

	/**
	 * Launch the application.
	 */
	public static void blank() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					blankPage window = new blankPage();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public blankPage() {
	
		initialize();
	
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 600, 470);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.getContentPane().setLayout(null);
	
		frame.getContentPane().setBackground(new Color(175, 238, 238));
	
		
		JLabel lblNewLabel = new JLabel("1. Yoko always puts extra fond in a plastic  ");
		lblNewLabel.setVerticalAlignment(SwingConstants.TOP);
		lblNewLabel.setHorizontalAlignment(SwingConstants.LEFT);
	
		lblNewLabel.setBounds(49, 93, 366, 21);
		frame.getContentPane().add(lblNewLabel);
		
		
		String[] answers={"sponge", "container", "elevator"};
		String [] answers2={"am use", "used", "am used"};
		String [] answers3={"was", "didn't", "wasn't"};
		String [] answers4={"is waiting", "has been waiting", "was waiting"};
		String [] answers7={"had left", "leaves", "left"};
		String [] answers6={"didn't go", "hadn't gone", "don't go"};
		String [] answers5={"down", "out", "in"};
		String [] answers8={"done", "am", "was"};
		
		
		JComboBox comboBox = new JComboBox(answers);
		comboBox.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(comboBox.getSelectedIndex()==1)  {
					
					scrores=scrores+1;
				}
				else {
				
					scrores=scrores-1;
				}
			}
		});
		comboBox.setBounds(317, 89, 109, 27);
		frame.getContentPane().add(comboBox);
		
		JLabel label = new JLabel("2. I                             to live in Madrid, but now I live in London.");
		label.setVerticalAlignment(SwingConstants.TOP);
		label.setHorizontalAlignment(SwingConstants.LEFT);
		label.setBounds(49, 123, 411, 21);
		frame.getContentPane().add(label);
		
		JLabel label_1 = new JLabel("3. He never                           the brightest student, but he did OK at school.");
		label_1.setVerticalAlignment(SwingConstants.TOP);
		label_1.setHorizontalAlignment(SwingConstants.LEFT);
		label_1.setBounds(49, 153, 494, 21);
		frame.getContentPane().add(label_1);
		
		JLabel label_2 = new JLabel("4. The poor man                                         there for an hour now!");
		label_2.setVerticalAlignment(SwingConstants.TOP);
		label_2.setHorizontalAlignment(SwingConstants.LEFT);
		label_2.setBounds(49, 183, 411, 21);
		frame.getContentPane().add(label_2);
		
		JLabel label_3 = new JLabel("5. The traffic was terrible. By the time I got to the station, the train ");
		label_3.setVerticalAlignment(SwingConstants.TOP);
		label_3.setHorizontalAlignment(SwingConstants.LEFT);
		label_3.setBounds(49, 213, 494, 21);
		frame.getContentPane().add(label_3);
		
		JLabel label_4 = new JLabel("6. If we                           out last night, we wouldn't have seen them.");
		label_4.setVerticalAlignment(SwingConstants.TOP);
		label_4.setHorizontalAlignment(SwingConstants.LEFT);
		label_4.setBounds(49, 243, 439, 21);
		frame.getContentPane().add(label_4);
		
		JLabel label_5 = new JLabel("7. He turned the job  ");
		label_5.setVerticalAlignment(SwingConstants.TOP);
		label_5.setHorizontalAlignment(SwingConstants.LEFT);
		label_5.setBounds(49, 273, 366, 21);
		frame.getContentPane().add(label_5);
		
		JLabel label_6 = new JLabel("8. I                             asleep until 10 o'clock!");
		label_6.setVerticalAlignment(SwingConstants.TOP);
		label_6.setHorizontalAlignment(SwingConstants.LEFT);
		label_6.setBounds(49, 303, 366, 21);
		frame.getContentPane().add(label_6);
		
		JComboBox comboBox_1 = new JComboBox(answers2);
		comboBox_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(comboBox_1.getSelectedIndex()==1)  {
					
					scrores=scrores+1;
				}
				else {
				
					scrores=scrores-1;
				}
			
			}
		});
		comboBox_1.setBounds(72, 116, 109, 27);
		frame.getContentPane().add(comboBox_1);
		
		JComboBox comboBox_2 = new JComboBox(answers3);
		comboBox_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(comboBox_2.getSelectedIndex()==0)  {
				
					scrores=scrores+1;
				}
				else {
			
					scrores=scrores-1;
				}
			
			}
		});
		comboBox_2.setBounds(122, 149, 98, 27);
		frame.getContentPane().add(comboBox_2);
		
		JComboBox comboBox_3 = new JComboBox(answers4);
		comboBox_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(comboBox_3.getSelectedIndex()==0)  {
				
					scrores=scrores+1;
				}
				else {
			
					scrores=scrores-1;
				}
			}
		});
		comboBox_3.setBounds(151, 179, 162, 27);
		frame.getContentPane().add(comboBox_3);
		
		JComboBox comboBox_4 = new JComboBox(answers6);
		comboBox_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(comboBox_4.getSelectedIndex()==0)  {
				
					scrores=scrores+1;
				}
				else {
			
					scrores=scrores-1;
				}
			}
		});
		comboBox_4.setBounds(96, 237, 109, 27);
		frame.getContentPane().add(comboBox_4);
		
		JComboBox comboBox_5 = new JComboBox(answers5);
		comboBox_5.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(comboBox_5.getSelectedIndex()==0)  {
			
					scrores=scrores+1;
				}
				else {
					
					scrores=scrores-1;
				}
			}
		});
		comboBox_5.setBounds(178, 266, 130, 27);
		frame.getContentPane().add(comboBox_5);
		
		JComboBox comboBox_6 = new JComboBox(answers7);
		comboBox_6.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(comboBox_6.getSelectedIndex()==0)  {
					
					scrores=scrores+1;
				}
				else {
					
					scrores=scrores-1;
				}
			}
		});
		comboBox_6.setBounds(470, 209, 130, 27);
		frame.getContentPane().add(comboBox_6);
		
		JComboBox comboBox_7 = new JComboBox(answers8);
		comboBox_7.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(comboBox_7.getSelectedIndex()==2)  {
					
					scrores=scrores+1;
				}
				else {
					
					scrores=scrores-1;
				}
			}
		});
		comboBox_7.setBounds(72, 299, 109, 27);
		frame.getContentPane().add(comboBox_7);
		
	
		
		JLabel label_7 = new JLabel("");
		Image img = new ImageIcon(this.getClass().getResource("/pp.png")).getImage();
		label_7.setIcon(new ImageIcon(img));
		label_7.setBounds(0, 0, 98, 80);
		frame.getContentPane().add(label_7);
		
		JLabel label_8 = new JLabel("");
		Image img1 = new ImageIcon(this.getClass().getResource("/pp.png")).getImage();
		label_8.setIcon(new ImageIcon(img1));
		label_8.setBounds(521, 0, 98, 80);
		frame.getContentPane().add(label_8);
		
		JLabel label_9 = new JLabel("");
		Image img2 = new ImageIcon(this.getClass().getResource("/pp.png")).getImage();
		label_9.setIcon(new ImageIcon(img2));
		label_9.setBounds(0, 348, 98, 80);
		frame.getContentPane().add(label_9);
		
		JLabel label_10 = new JLabel("");
		Image img3 = new ImageIcon(this.getClass().getResource("/pp.png")).getImage();
		label_10.setIcon(new ImageIcon(img3));
		label_10.setBounds(521, 348, 98, 80);
		frame.getContentPane().add(label_10);
		
		JLabel label_11 = new JLabel("");
		label_11.setBounds(262, 360, 88, 16);
		frame.getContentPane().add(label_11);
		
		JMenuBar menuBar = new JMenuBar();
		frame.setJMenuBar(menuBar);
		JMenu mnNewMenu = new JMenu("File");
		menuBar.add(mnNewMenu);
		JMenuItem mntmGame = new JMenuItem("Go to Theory Page");
		mntmGame.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				theoryPage theory=new theoryPage();
				theory.theory();
			}
		});
		
		mnNewMenu.add(mntmGame);
		
		JMenuItem mntmNewMenuItem = new JMenuItem("Exit");
		mntmNewMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(JFrame.EXIT_ON_CLOSE);
			}
		});
		mnNewMenu.add(mntmNewMenuItem);
		frame.getContentPane().setLayout(null);
		
		JButton btnFinished = new JButton("Finished");
		btnFinished.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				JOptionPane.showMessageDialog(frame, "Scores " + scrores);
			}
		});
		btnFinished.setBounds(259, 347, 117, 29);
		frame.getContentPane().add(btnFinished);
		
		JLabel lblNewLabel_1 = new JLabel("Check Your Knowledge About English Grammar!");
		lblNewLabel_1.setFont(new Font("Lucida Grande", Font.BOLD, 13));
		lblNewLabel_1.setBounds(138, 20, 334, 47);
		frame.getContentPane().add(lblNewLabel_1);
	}

	

}
