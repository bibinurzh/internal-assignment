import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Image;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.border.Border;

public class pastSimple {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void past() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					pastSimple window = new pastSimple();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public pastSimple() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame("Past Simple");
		frame.setBounds(100, 100, 700, 700);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		frame.getContentPane().setBackground(new Color(175, 238, 238));
		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setBounds(6, 6, 98, 80);
		Image img = new ImageIcon(this.getClass().getResource("/pp.png")).getImage();
		lblNewLabel_1.setIcon(new ImageIcon(img));
		frame.getContentPane().add(lblNewLabel_1);
		
		JLabel label = new JLabel("");
		label.setIgnoreRepaint(true);
		label.setBounds(6, 584, 98, 90);
		Image img1 = new ImageIcon(this.getClass().getResource("/pp.png")).getImage();
		label.setIcon(new ImageIcon(img1));
		frame.getContentPane().add(label);
		
		JLabel label_1 = new JLabel("");
		label_1.setBounds(613, 6, 81, 80);
		Image img2 = new ImageIcon(this.getClass().getResource("/pp.png")).getImage();
		label_1.setIcon(new ImageIcon(img2));
		frame.getContentPane().add(label_1);
		
		JLabel label_2 = new JLabel("");
		label_2.setBounds(619, 584, 75, 90);
		Image img3 = new ImageIcon(this.getClass().getResource("/pp.png")).getImage();
		label_2.setIcon(new ImageIcon(img3));
		frame.getContentPane().add(label_2);
		
		
		JTextArea txtrPastSimpleTense = new JTextArea();
		txtrPastSimpleTense.setBackground(new Color(175, 238, 238));
		txtrPastSimpleTense.setWrapStyleWord(true);
		txtrPastSimpleTense.setLineWrap(true);
		txtrPastSimpleTense.setText("• Regular verbs (Дұрыс етістіктер)\nАғылшын тілінде етістіктерді өткен шақта жазу үшін негізгі етістіктің соңына -ed жалғауы жалғанады. \nМысалы: play → played, watch → watched, work → worked және сол сияқты.\nАл егер де етістік e әрібімен бітсе, соңына тек ғана -d жалғауы жалғанады. \nМысалы: compare → compared, arrive → arrived, paste → pasted және сол сияқты.\nЖоғарыдағыдай атап өткеніміздей, өткен шақта -ed/-d жалғаулары қосылу арқылы жасалатын етістіктерді дұрыс етістіктер деп атайды.\n\n• Irregular Verbs (Бұрыс етістіктер)\nАғылшын тілінде етістіктерді өткен шақта жазу үшін негізгі етістіктің соңына -ed/-d және басқа да жалғаулар жалғанбастан түбірден өзгеріп жасалатын етістіктер бар. Олардыды бұрыс етістіктер деп атайды. \nМысалы: go → went, write → wrote, come → came, sleep → slept және сол сияқты.\nЖоғарыдағыдай атап өткеніміздей, өткен түбірден өзгеріп жасалатын етістіктерді бұрыс етістіктер деп атайды.\nБұрыс етістіктердің жасалауының ешқандай ережесі жоқ. Олардың ағылшын тілінде белгілі бір кестесі бар. Төмендегі кестені міндетті түрде жаттап алу керек.\n\n• Frequency Adverbs (Уақыт үстеулері)\nАғылшын тілі сөйлемдерінде өткен шақты білдіру үшін уақыт үстеулері қолданылады. \nМысалы: yesterday → кеше, the day before yesterday → алдыңғы күн, last week (month, year, century and so on) → өткен апта (ай, жыл, ғасыр және т.б), two weeks ago (three months ago, seven years ago and so on) → екі апта бұрын (үш ай бұрын, жеті жыл бұрын және т.б) және сол сияқты.\n\n• Affirmative Form (Болымды форма)\nAffirmative (Болымды) —Translation (Аудармасы) \nI played football yesterday — Мен кеше футбол ойнадым\nYou started lesson last week — Сен сабағыңды өткен аптада бастадың\nHe(she) watched TV last night — Ол (қыз не ұл) өткен түнде ТВ көрді\nWe went to Astana 2 months ago — Біз Астанаға екі ай бұрын кеттік\nYou gave money the day before yesterday — Сендер ақшаны алдыңғы күні бердіңдер\nThey worked three years ago — Олар үш апта бұрын жұмыс істеді\n\n• Negative Form (Болымсыз форма)\nNegative (Болымсыз) — Translation (Аудармасы)\nI didn’t play football yesterday — Мен кеше футбол ойнамадым\nYou didn’t start lesson last week — Сен сабағыңды өткен аптада бастамадың\nHe(she) didn’t watch TV last night — Ол (қыз не ұл) өткен түнде ТВ көрмеді\nWe didn’t go to Astana 2 months ago — Біз Астанаға екі ай бұрын кетпедік\nYou didn’t gіve money the day before yesterday — Сендер ақшаны алдыңғы күні бермедіңдер\nThey didn’t work three years ago — Олар үш апта бұрын жұмыс істемеді\n\n• Interrogative Form (Сұрақ форма)\nQuestion (Сұрақ) — Answer (Жауап) \nDid I play football? Мен футбол ойнадым ба? — Yes, you did Иә / No, you did not (No, you didn’t) Жоқ\nDid you start lesson? Сен сабағыңды бастадың ба? — Yes, I did Иә / No, I did not (No, I didn’t) Жоқ\nDid he(she) watch TV? Ол ТВ көрді ме? — Yes, he(she) did Иә / No, he(she) did not (No, he(she) didn’t) Жоқ\nDid we go to Astana? Біз Астанаға бардық па? — Yes, you did Иә / No, you did not (No, we didn’t) Жоқ\nDid you gіve money? Сендер ақша бердіңдер ме? — Yes, we did Иә / No, we did not (No, we didn’t) Жоқ\nDid they work? Олар жұмыс істеді ме? — Yes, they did Иә / No, they did not (No, they didn’t) Жоқ");
		txtrPastSimpleTense.setBounds(0, 0, 700, 678);
		txtrPastSimpleTense.setEditable(false);
		frame.getContentPane().add(txtrPastSimpleTense);
		
		JScrollPane scrollPane = new JScrollPane(txtrPastSimpleTense, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		scrollPane.setBounds(16, 108, 684, 479);
		frame.getContentPane().add(scrollPane);
		Border emptyBorder = BorderFactory.createEmptyBorder(0, 0, 0, 0);
		scrollPane.setBorder(emptyBorder);
		
		JTextArea txtrPastSimpleTense_1 = new JTextArea();
		txtrPastSimpleTense_1.setEditable(false);
		txtrPastSimpleTense_1.setBackground(new Color(175, 238, 238));
		txtrPastSimpleTense_1.setLineWrap(true);
		txtrPastSimpleTense_1.setWrapStyleWord(true);
		txtrPastSimpleTense_1.setText("\tPast Simple Tense (Жай өткен шақ) – өткен шақтағы болған іс-әрекетті білдіреді. Сөйлеушінің сөйлеп жатқан кезінен бұрын болған іс-қимылды осы етістік арқылы тыңдаушыға жеткізе аламыз. Мысалы:\nI finished my homework – Мен үй жұмысымды аяқтадым. (сөйлеуші үй жұмысын өткен шақта аяқтағанын, яғни тыңдаушыға айтпас бұрын өз үй жұмысын аяқтап болғанын жеткізіп жатыр).");
		txtrPastSimpleTense_1.setBounds(92, 6, 509, 96);
		frame.getContentPane().add(txtrPastSimpleTense_1);
	}

}
