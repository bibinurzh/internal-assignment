import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Image;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenuBar;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.border.Border;
import javax.swing.border.EmptyBorder;
import javax.swing.JTextArea;

public class articles {

	private JFrame frame;
	private JTextArea textArea;

	/**
	 * Launch the application.
	 */
	public static void articles(){
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					articles window = new articles();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public articles() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame("The Articles");
		frame.getContentPane().setBackground(new Color(175, 238, 238));
		frame.setBackground(new Color(175, 238, 238));
		frame.setBounds(100, 100, 700, 700);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setBounds(6, 6, 98, 90);
		Image img = new ImageIcon(this.getClass().getResource("/pp.png")).getImage();
		lblNewLabel_1.setIcon(new ImageIcon(img));
		frame.getContentPane().add(lblNewLabel_1);
		
		JLabel label = new JLabel("");
		label.setIgnoreRepaint(true);
		label.setBounds(6, 574, 83, 100);
		Image img1 = new ImageIcon(this.getClass().getResource("/pp.png")).getImage();
		label.setIcon(new ImageIcon(img1));
		frame.getContentPane().add(label);
		
		JLabel label_1 = new JLabel("");
		label_1.setBounds(619, 6, 75, 90);
		Image img2 = new ImageIcon(this.getClass().getResource("/pp.png")).getImage();
		label_1.setIcon(new ImageIcon(img2));
		frame.getContentPane().add(label_1);
		
		JLabel label_2 = new JLabel("");
		label_2.setBounds(619, 584, 75, 90);
		Image img3 = new ImageIcon(this.getClass().getResource("/pp.png")).getImage();
		label_2.setIcon(new ImageIcon(img3));
		frame.getContentPane().add(label_2);
		
		JTextArea txtrTheIndefinite = new JTextArea();
		txtrTheIndefinite.setEditable(false);
		txtrTheIndefinite.setBackground(new Color(175, 238, 238));
		txtrTheIndefinite.setWrapStyleWord(true);
		txtrTheIndefinite.setLineWrap(true);
		txtrTheIndefinite.setText("\n► The indefinite article: a (an)\nA (an – дауыстылардың алдында) артиклі көне ағылшын тіліндегі An (бір) деген сөзден шыққан. A артиклі өзінен кейін тұрған заттың көп заттың ішіндегі бір зат екендігін білдіреді. Ол зат көп заттардың арасындағы кез-келген біреуі болуы мүмкін. Ол зат жайлы алдын-ала айтылмаған. Әңгімелеуші адам алғаш рет айтып, таныстырып отыр.\nМысалы:\nI am a student (Мен – студентпін). Көп студенттің бірімін. Егер мен студенттердің арасындағы ерекше студент болсам, онда басқаша айтылған болар еді.\nThis is an apple (Бұл – алма). Адам санап болмайтын алмалардың біреуі ғана. Ол алманың нақты қандай алма екендігі туралы ештеңе айтылып тұрған жоқ.\rБайқасаңыздар, белгісіздік артикльдеріне келтірілген жоғарыдағы мысалдарда студент пен алма жайлы ешқандай тура дерек, сипаттама, ақпарат жоқ. Тек студент екендігі, алма екендігі ғана айтылды. Ал қалған ақпараттар мәлім емес. \nЕскерту!\nБелгісіздік артикльдері тек жекеше түрдегі зат есімдердің алдына қойылады. Көпше түрдегі нұсқасында артикль түсіп қалады. Мысалы:\nI am a student. | We are students (Біз – студентпіз).\n\n►The definite article: The (зэ)\nThe белгілілік артиклі ағылшын тілінде көнеден келе жатқан that (анау, әлгі) нұсқаулық артиклінен шыққан. The артиклі заттардың барлық (жекеше/көпше) түрлеріне қолданылады.\nБелгілілік артиклінің қолданылуы:\n1) Сөз (әңгіме) белгілі зат жайында болғанда\nМыс.: Where is the bag (Сөмке қайда?)? Бұл жердегі сөмке деп отырғанымыз белгілі сөмке. Ол менің немесе сіздің сөмкеңіз екендігі анық.\n2) Зат есімдер асырмалы шырайда тұрса (мыс: Ең күшті, ең …), алдында реттік сан есімдері болса. Мыс.: Satpaev is the first geologist in our country (Сәтбаев – еліміздегі ең алғашқы геолог).\n3) Географиялық атаулардың (тау, теңіз, көл, өзен т.с.с. атаулары) алдында. Мыс.: The Caspian sea, the North, the Indian ocean, the Alatau mountains\n4) Өзінің тобының (өзіне ұқсас заттардың арасында) жалғызы ғана болатын зат есімдердің алдында. Мыс.: The Nile is the longest river in the world (Ніл – әлемдегі ең ұзын өзен). Ніл өзені ғана әлемдегі ең ұзын өзен. \n5) Кейбір сөз тіркестерінде. Мыс.: in the morning, in the afternoon\n\n►Zero article (Нөл артикль)\rZero article дегеніміз ешқандай артикль емес, жай ғана бос орын. Нөл артикльдің қолданылуы, яғни, ешқандай артикль қолданылмайтын жағдайлар:\n1) Жинақтық, жалпылай айтылатын зат есімдердің алдында\rМыс.: Crime is a problem in most cities (Қылмыс – көптеген қалалардағы мәселе). Қылмыстың қандай түрі екендігі айтылмайды. Жалпы алғандағы қылмыс жайлы айтылып тұр.\n2) Ел-жер, адам аттарының алдында. Мыс.: Mr. Mamyrov, Astana, Kazakhstan, China\nЕскерту!\nОтбасыны немесе әулетті фамилиясына байланысты атаса, онда The артиклі қойылады. Мысалы: The Johnsons (Джонсондар отбасы немесе әулеті)\n3) Жыл мезгілдерінің, ай аттарының және апта күндерінің алдында. Мыс.: Autumn is rainy. July is the hottest month. We don’t work on Saturday.\n");
		txtrTheIndefinite.setBounds(0, 0, 700, 678);
		frame.getContentPane().add(txtrTheIndefinite);
		
		JScrollPane scrollPane = new JScrollPane(txtrTheIndefinite, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		scrollPane.setBounds(10, 124, 690, 468);
		frame.getContentPane().add(scrollPane);
		Border emptyBorder = BorderFactory.createEmptyBorder(0, 0, 0, 0);
		scrollPane.setBorder(emptyBorder);
		
		JTextArea textArea_1 = new JTextArea();
		textArea_1.setEditable(false);
		textArea_1.setBackground(new Color(175, 238, 238));
		textArea_1.setLineWrap(true);
		textArea_1.setWrapStyleWord(true);
		textArea_1.setText("\tАртикльдер – зат есімдердің алдына қойылатын қызметші сөздер. Ағылшын тіліндегі артикльдер затқа қосымша сипаттама береді, яғни, қосымша ақпарат беріп тұрады. Қазақ және орыс тілдерінде артикльдер жоқ. Ағылшын тілінде артикльдердің екі түрі бар: белгілілік артиклі (the definite article) және белгісіздік артиклі (the indefinite article). Бұл екеуінен бөлек, артикль қойылмайтын кездердегі бос орынды Zero article (нөл артикль) деп атайды.\n");
		textArea_1.setBounds(93, 6, 514, 115);
		frame.getContentPane().add(textArea_1);
		
		
		
		
	}

}
