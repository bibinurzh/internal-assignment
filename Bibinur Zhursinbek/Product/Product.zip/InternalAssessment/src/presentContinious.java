import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Image;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.border.Border;

public class presentContinious {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void presCont() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					presentContinious window = new presentContinious();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public presentContinious() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame("Present Continuous");
		frame.setBounds(100, 100, 700, 700);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		frame.getContentPane().setBackground(new Color(175, 238, 238));
	
		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setBounds(6, 6, 98, 80);
		Image img = new ImageIcon(this.getClass().getResource("/pp.png")).getImage();
		lblNewLabel_1.setIcon(new ImageIcon(img));
		frame.getContentPane().add(lblNewLabel_1);
		
		JLabel label = new JLabel("");
		label.setIgnoreRepaint(true);
		label.setBounds(6, 584, 98, 90);
		Image img1 = new ImageIcon(this.getClass().getResource("/pp.png")).getImage();
		label.setIcon(new ImageIcon(img1));
		frame.getContentPane().add(label);
		
		JLabel label_1 = new JLabel("");
		label_1.setBounds(613, 6, 81, 80);
		Image img2 = new ImageIcon(this.getClass().getResource("/pp.png")).getImage();
		label_1.setIcon(new ImageIcon(img2));
		frame.getContentPane().add(label_1);
		
		JLabel label_2 = new JLabel("");
		label_2.setBounds(619, 584, 75, 90);
		Image img3 = new ImageIcon(this.getClass().getResource("/pp.png")).getImage();
		label_2.setIcon(new ImageIcon(img3));
		frame.getContentPane().add(label_2);
		
		JTextArea txtrPresentContinuousTense = new JTextArea();
		txtrPresentContinuousTense.setBounds(25, -27, 696, 674);
		txtrPresentContinuousTense.setBackground(new Color(175, 238, 238));
		txtrPresentContinuousTense.setWrapStyleWord(true);
		txtrPresentContinuousTense.setLineWrap(true);
		txtrPresentContinuousTense.setText("\nМысалы: Azat is eating — Азат тамақтанып отыр\nAzat — Subject\nis — to be етістігі\neating — verb+ing\n\nАғылшын тіліндегі нақ осы шақ -ing (АйЭнДжи) жалғауының жалғануы арқылы ерекшеленсе, қазақ тіліндегі нақ осы шақ «отыр», «жатыр», «тұр» етістіктері арқылы жасалады.\n\nНақ осы шақтағы сөйлемдердің түрлері:\n• Жай сөйлем: We are playing football.\n• Сұраулы: Are we playing football?\n• Болымсыз: We are not playing football.");
		txtrPresentContinuousTense.setEditable(false);
		frame.getContentPane().add(txtrPresentContinuousTense);
		
		JScrollPane scrollPane = new JScrollPane(txtrPresentContinuousTense, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		scrollPane.setBounds(16, 182, 684, 239);
		frame.getContentPane().add(scrollPane);
		Border emptyBorder = BorderFactory.createEmptyBorder(0, 0, 0, 0);
		scrollPane.setBorder(emptyBorder);
		
		JTextArea txtrPresentContinuousTense_1 = new JTextArea();
		txtrPresentContinuousTense_1.setEditable(false);
		txtrPresentContinuousTense_1.setBackground(new Color(175, 238, 238));
		txtrPresentContinuousTense_1.setWrapStyleWord(true);
		txtrPresentContinuousTense_1.setLineWrap(true);
		txtrPresentContinuousTense_1.setText("                    Present Continuous Tense (Present Progressive Tense) — нақ осы шақ немесе созылыңқы осы шақ — тура әңгіме болып жатқан кездегі іс-әрекеттерді сипаттайды. Мысалы: I am writing a letter — Мен хат жазып отырмын. Ағылшын тіліндегі нақ осы шақтың жасалу жолы (формуласы)");
		txtrPresentContinuousTense_1.setBounds(94, 16, 494, 70);
		frame.getContentPane().add(txtrPresentContinuousTense_1);
		Image img4 = new ImageIcon(this.getClass().getResource("/contin.png")).getImage();
		
		JLabel lblNewLabel_2 = new JLabel("");
		lblNewLabel_2.setBounds(192, 421, 300, 110);
		Image img5 = new ImageIcon(this.getClass().getResource("/prcon-300x77.png")).getImage();
		lblNewLabel_2.setIcon(new ImageIcon(img5));
		frame.getContentPane().add(lblNewLabel_2);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setBounds(66, 98, 574, 86);
		frame.getContentPane().add(lblNewLabel);
		lblNewLabel.setIcon(new ImageIcon(img4));
	}
}
