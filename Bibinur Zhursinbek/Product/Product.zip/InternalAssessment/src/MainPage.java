import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import java.io.IOException;

import java.util.Random;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;

import javax.swing.SwingConstants;

public class MainPage {
	private Random random;
	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args)  {

		

		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					MainPage window = new MainPage();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 * @throws IOException 
	 */
	public MainPage() throws IOException {
		initialize();
	
	}

	/**
	 * Initialize the contents of the frame.
	 * @throws IOException 
	 */



	private void initialize() throws IOException {
		frame = new JFrame("Learn English language with Bibinur");
		frame.getContentPane().setBackground(new Color(175, 238, 238));
		frame.setBounds(100, 100, 600, 450);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.setResizable(false);
		frame.getContentPane().setLayout(null);
		JLabel lblNewLabel = new JLabel("<html> Hello, Dear User! <br> Do you want to start the game or learn the theory first?<br>If you want to play press the button - <b>Game</b> <br>  or press the button - Theory in order to learn the language. </hmtl>");
		lblNewLabel.setBounds(137, 36, 392, 80);
		lblNewLabel.setVerticalAlignment(SwingConstants.TOP);
		lblNewLabel.setHorizontalAlignment(SwingConstants.LEFT);
		lblNewLabel.setFont(new Font("Century Gothic", Font.BOLD, 13));
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel1 = new JLabel("<html> Сәлем, Құрметті Пайдаланушы!<br> Сіз Ойынды бастау келеді ме немесе біріншіден теориясын білуне келеді ме?<br> Егер ойнауға тілейсіз – Play түймесін басыңыз <br> немесе тілді үйрену үшін - Theory түймесін басыңыз.</hmtl>");
		lblNewLabel1.setBounds(188, 128, 406, 96);
		lblNewLabel1.setVerticalAlignment(SwingConstants.TOP);
		lblNewLabel1.setFont(new Font("Century Gothic", Font.BOLD, 13));
		frame.getContentPane().add(lblNewLabel1);
		
		JButton btnNewButton = new JButton("Game");
		btnNewButton.setBounds(334, 315, 117, 51);
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				gamePage game=new gamePage();
				game.game();
			}
		});
		frame.getContentPane().add(btnNewButton);
		
		JButton btnNewButton_1 = new JButton("Theory");
		btnNewButton_1.setBounds(172, 315, 117, 51);
		btnNewButton_1.setBackground(Color.CYAN);
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
						theoryPage theory=new theoryPage();
						theory.theory();
			}
		});
		frame.getContentPane().add(btnNewButton_1);
		
		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setBounds(6, 6, 98, 80);
		Image img = new ImageIcon(this.getClass().getResource("/pp.png")).getImage();
		lblNewLabel_1.setIcon(new ImageIcon(img));
		frame.getContentPane().add(lblNewLabel_1);
		
		JLabel label = new JLabel("");
		label.setBounds(6, 315, 98, 90);
		Image img1 = new ImageIcon(this.getClass().getResource("/pp.png")).getImage();
		label.setIcon(new ImageIcon(img1));
		frame.getContentPane().add(label);
		
		JLabel label_1 = new JLabel("");
		label_1.setBounds(519, 6, 81, 80);
		Image img2 = new ImageIcon(this.getClass().getResource("/pp.png")).getImage();
		label_1.setIcon(new ImageIcon(img2));
		frame.getContentPane().add(label_1);
		
		JLabel label_2 = new JLabel("");
		label_2.setBounds(519, 315, 75, 90);
		Image img3 = new ImageIcon(this.getClass().getResource("/pp.png")).getImage();
		label_2.setIcon(new ImageIcon(img3));
		frame.getContentPane().add(label_2);
		
		JLabel lblNewLabel_2 = new JLabel("");
		lblNewLabel_2.setBounds(6, 105, 181, 180);
		Image img4 = new ImageIcon(this.getClass().getResource("/individual.png")).getImage();
		lblNewLabel_2.setIcon(new ImageIcon(img4));
		frame.getContentPane().add(lblNewLabel_2);
		
		JMenuBar menuBar = new JMenuBar();
		frame.setJMenuBar(menuBar);
		
		JMenu mnNewMenu = new JMenu("File");
		menuBar.add(mnNewMenu);
		
		JMenuItem mntmNewMenuItem = new JMenuItem("Exit");
		mntmNewMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(JFrame.EXIT_ON_CLOSE);
			}
		});
		
		JMenuItem mntmHelp = new JMenuItem("Help");
		mntmHelp.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				helpFile help=new helpFile();
				help.help();
			}
		});
		mnNewMenu.add(mntmHelp);
		mnNewMenu.add(mntmNewMenuItem);
		
		


	}
}
