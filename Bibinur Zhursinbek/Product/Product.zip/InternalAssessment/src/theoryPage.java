import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import java.awt.Color;

public class theoryPage {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void theory() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					theoryPage window = new theoryPage();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public theoryPage() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.getContentPane().setBackground(new Color(175, 238, 238));
		frame.setBounds(100, 100, 600, 450);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		
		JMenuBar menuBar = new JMenuBar();
		frame.setJMenuBar(menuBar);
		JMenu mnNewMenu = new JMenu("File");
		menuBar.add(mnNewMenu);
		
		JMenuItem mntmGame = new JMenuItem("Go to Game Page");
		mntmGame.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				gamePage game=new gamePage();
				game.game();
			}
		});
		mnNewMenu.add(mntmGame);
		
		JMenuItem mntmNewMenuItem = new JMenuItem("Exit");
		mntmNewMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(JFrame.EXIT_ON_CLOSE);
			}
		});
		mnNewMenu.add(mntmNewMenuItem);
		frame.getContentPane().setLayout(null);

		JLabel lblNewLabel_2 = new JLabel("Бастауыш (Beginner)");
		lblNewLabel_2.setFont(new Font("Gill Sans MT", Font.BOLD, 16));
		lblNewLabel_2.setBounds(57, 142, 165, 29);
		frame.getContentPane().add(lblNewLabel_2);
		
		JLabel lbladvanced = new JLabel("Ілгері (Advanced)");
		lbladvanced.setFont(new Font("Gill Sans MT", Font.BOLD, 16));
		lbladvanced.setBounds(255, 142, 136, 29);
		frame.getContentPane().add(lbladvanced);
		
		JLabel lblproficient = new JLabel("Сарапшы (Proficient)");
		lblproficient.setFont(new Font("Gill Sans MT", Font.BOLD, 16));
		lblproficient.setBounds(413, 142, 167, 29);
		frame.getContentPane().add(lblproficient);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setBounds(276, 29, 75, 81);
		Image img = new ImageIcon(this.getClass().getResource("/pen.png")).getImage();
		frame.getContentPane().setLayout(null);
		lblNewLabel.setIcon(new ImageIcon(img));
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setBounds(6, 6, 97, 85);
		Image img1 = new ImageIcon(this.getClass().getResource("/pp.png")).getImage();
		lblNewLabel_1.setIcon(new ImageIcon(img1));
		frame.getContentPane().add(lblNewLabel_1);
		
		JLabel label = new JLabel("");
		label.setBounds(6, 321, 97, 85);
		Image img2 = new ImageIcon(this.getClass().getResource("/pp.png")).getImage();
		label.setIcon(new ImageIcon(img2));
		frame.getContentPane().add(label);
		
		JLabel label_1 = new JLabel("");
		label_1.setBounds(519, 321, 75, 85);
		Image img3 = new ImageIcon(this.getClass().getResource("/pp.png")).getImage();
		label_1.setIcon(new ImageIcon(img3));
		frame.getContentPane().add(label_1);
		
		JLabel label_2 = new JLabel("");
		label_2.setBounds(519, 6, 75, 85);
		Image img4 = new ImageIcon(this.getClass().getResource("/pp.png")).getImage();
		label_2.setIcon(new ImageIcon(img4));
		frame.getContentPane().add(label_2);
	
		JButton btn1 = new JButton("Present Simple");
		btn1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				presentSimple present=new presentSimple();
				present.present();
			}
		});
		btn1.setBounds(244, 187, 153, 44);
		frame.getContentPane().add(btn1);
		
		JButton btn2 = new JButton("Past Simple");
		btn2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				pastSimple past=new pastSimple();
				past.past();
			}
		});
		btn2.setBounds(244, 226, 153, 44);
		frame.getContentPane().add(btn2);
		
		JButton btnFutureSimple = new JButton("Future Simple");
		btnFutureSimple.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				futureSimple future=new futureSimple();
				future.future();
				
			}
		});
		btnFutureSimple.setBounds(244, 265, 153, 44);
		frame.getContentPane().add(btnFutureSimple);
		
		JButton btnPresCont = new JButton("Present Continuous");
		btnPresCont.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				presentContinious presentCon=new presentContinious();
				presentCon.presCont();
			}
		});
		btnPresCont.setBounds(426, 248, 154, 47);
		frame.getContentPane().add(btnPresCont);
		
		JButton btnPronouns = new JButton("Pronouns");
		btnPronouns.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				pronouns pronouns=new pronouns();
				pronouns.pronouns();
				
			}
		});
		btnPronouns.setBounds(57, 185, 154, 46);
		frame.getContentPane().add(btnPronouns);
		
		JButton btnArticles = new JButton("Articles");
		btnArticles.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				articles articles =new articles();
				articles.articles();
			}
		});
		btnArticles.setBounds(57, 226, 153, 44);
		frame.getContentPane().add(btnArticles);
		
		JButton btnReportedSpeech = new JButton("Modal verbs");
		btnReportedSpeech.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				modalVerbs modal =new modalVerbs();
				modal.verbs();
				
			}
		});
		btnReportedSpeech.setBounds(425, 203, 153, 47);
		frame.getContentPane().add(btnReportedSpeech);
		
		JButton btnPreposition = new JButton("Prepositions");
		btnPreposition.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				prepositions prepositions = new prepositions();
				prepositions.prepositions();
				
			}
		});
		btnPreposition.setBounds(57, 265, 153, 44);
		frame.getContentPane().add(btnPreposition);
		JMenuItem mntmHelp = new JMenuItem("Help");
		mntmHelp.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				helpFile help=new helpFile();
				help.help();
			}
		});
		mnNewMenu.add(mntmHelp);
		mnNewMenu.add(mntmNewMenuItem);
		
		
		
	}

}
