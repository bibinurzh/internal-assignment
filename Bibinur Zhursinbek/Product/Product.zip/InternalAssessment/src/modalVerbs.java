import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Image;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.border.Border;

public class modalVerbs {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void verbs() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					modalVerbs window = new modalVerbs();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public modalVerbs() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame("Modal Verbs");
		frame.setBounds(100, 100, 700, 700);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		frame.getContentPane().setBackground(new Color(175, 238, 238));
		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setBounds(6, 6, 98, 80);
		Image img = new ImageIcon(this.getClass().getResource("/pp.png")).getImage();
		lblNewLabel_1.setIcon(new ImageIcon(img));
		frame.getContentPane().add(lblNewLabel_1);
		
		JLabel label = new JLabel("");
		label.setIgnoreRepaint(true);
		label.setBounds(6, 584, 98, 90);
		Image img1 = new ImageIcon(this.getClass().getResource("/pp.png")).getImage();
		label.setIcon(new ImageIcon(img1));
		frame.getContentPane().add(label);
		
		JLabel label_1 = new JLabel("");
		label_1.setBounds(613, 6, 81, 80);
		Image img2 = new ImageIcon(this.getClass().getResource("/pp.png")).getImage();
		label_1.setIcon(new ImageIcon(img2));
		frame.getContentPane().add(label_1);
		
		JLabel label_2 = new JLabel("");
		label_2.setBounds(619, 584, 75, 90);
		Image img3 = new ImageIcon(this.getClass().getResource("/pp.png")).getImage();
		label_2.setIcon(new ImageIcon(img3));
		frame.getContentPane().add(label_2);
		
		
		JTextArea txtrMayme = new JTextArea();
		txtrMayme.setEditable(false);
		txtrMayme.setBackground(new Color(175, 238, 238));
		txtrMayme.setWrapStyleWord(true);
		txtrMayme.setLineWrap(true);
		txtrMayme.setText("• May [meı] — ықтималдылықты (болуы мүмкін), рұқсат сұрауды немесе рұқсат беруді білдіретін модальді етістік. Өткен шақта may және might екеуін де қолдана беруге болады.\nExamples:\n    Possibility (ықтималдылық): He may be in the garden (Мүмкін, ол бақшада болар)\n    Request permission (рұқсат сұрау): May I come in? (Кіруге рұқсат па?)\n    Give permission (рұқсат беру): Yes, you may come in (Иә, кіруіңе болады (кіруге болады))\n\n• May модальді етістігінің өте сыпайы түрі: Might [maıt]\nMight модальді етістігін May-дің баламасы ретінде де қолдана беруге болады. Сондай-ақ, біреуге ұсыныс жасағанда, шартты сөйлемдерде Might қолданылады. Might модальді етістігінің болымсыз түрі: might not, mightn’t [maıtnt]. Examples:\nYour socks might be in the bathroom (Сенің шұлықтарың жуынатын (вана) бөлмеде болуы мүмкін).\nMight I borrow your mobile phone? (Мен сіздің ұялы телефоныңызды ала тұрсам бола ма?).\nYour parents might visit me next week (Сенің ата-анаң маған келесі аптада келе алады) ұсыныс ретінде\n\n• Must [mʌst] модальді етістігі жүктелген міндетті, тыйым салынған немесе қатаң түрде бекітілген нұсқауды, бұйрықты айтып жеткізу кезінде қолданылады. Must етістігінің болымсыз түрі: mus not [mʌsnt].\nЕскерту! must модальді етістігі өткен шақта қолданылмайды. Оның орнына баламалы тіркестер қолданылады. Мысалы: have to, allowed to.\nMust модальді етістігіне мысалдар:\nThis must be the right answer! — Бұл дұрыс жауап болуы тиіс.\nStudents must pass an entrance examination — Студенттер қабылдау емтиханынан өтулері керек.\nErbol, you must not play in the street! — Ербол, сен көшеде ойнамауға тиіссің.\nI must play football — Мен футбол ойнауға тиістімін (міндеттімін).\nHe must work hard if he wants to pass his exam — Ол емтиханнан өткісі келсе, белсенді (үздіксіз) еңбектенуі керек.\n\n• Болымды түрі: can [кән, кэн]; болымсыз түрі: can not [кә(э)ннот, кә(э)ннат] немесе cannot; болымсыз түрінің қысқарған түрі: can’t [кәнт, кант].\nCan модальді етістігі қазақшаға сөзбе-сөз аударылмайды. Мағыналық тұрғыдан қарастырсақ, бір істі, әрекетті істеуге мүмкіншіліктің болуын білдіреді. Қазақ тілінде балама болу ғалайықты деп, «етістік + алу» деген грамматикалық формуланы ереже етуімізге болады. Мұндағы «етістік» дегеніміз етістіктің түбіріне -а, -е, -и, -й жалғауларының жалғанған нұсқасы. Ал «алу» дегеніміз көмекші етісік, жіктеледі (аламын, аласың, алады, …). Болымсыз түрінде «алу» көмекші етістігі «алмау» болып қолданылады. Мысалы: айта алмау, бара алу, келе алу,  оқи алу. Мысалы:\nI can speak English — Мен ағылшынша сөйлей аламын.\nHe can not come — Ол келе алмайды.\nShe is very shy. So she can not ask anything — Ол (жынысы: әйел) — ұялшақ. Сондықтан ештеңе сұрай алмайды.\nCan модальді етістігінің өткен шақтағы нұсқасы: could [куд] (could not, couldn’t [куднт])\nWhen I was 5-year-old, could not ride a bicycle — Мен бес жасымда (бес жаста болғанда) велосипед тебе алмадым.\nCould I use your computer to surf  Internet? — Мен сіздің компьютеріңізді Интернетке кіру (Интернетті шолу) үшін пайдалана аламын ба?\n\n");
		txtrMayme.setBounds(0, 0, 700, 678);
		frame.getContentPane().add(txtrMayme);
		
		JScrollPane scrollPane = new JScrollPane(txtrMayme, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		scrollPane.setBounds(16, 98, 684, 481);
		frame.getContentPane().add(scrollPane);
		Border emptyBorder = BorderFactory.createEmptyBorder(0, 0, 0, 0);
		scrollPane.setBorder(emptyBorder);
		
		JTextArea textArea = new JTextArea();
		textArea.setEditable(false);
		textArea.setBackground(new Color(175, 238, 238));
		textArea.setWrapStyleWord(true);
		textArea.setLineWrap(true);
		textArea.setText("\tМодальді етістіктер деген түсінік қазақ тілінде мүлдем жоқ.  Модальді етістіктер — сөйлемге қатысатын негізгі емес етістіктердің тобы. Олардың қатарына мына етістіктер жатады (жақшада өткен шақтағы түрі): can (could), could, may (might), might, must (had to), have to, ought to, should, would, need to.");
		textArea.setBounds(99, 6, 502, 90);
		frame.getContentPane().add(textArea);
	}

}
