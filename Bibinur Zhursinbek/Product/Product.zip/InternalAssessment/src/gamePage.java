import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

public class gamePage {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void game() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					gamePage window = new gamePage();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public gamePage() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setResizable(false);
		frame.setBounds(100, 100, 600, 450);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		frame.getContentPane().setBackground(new Color(175, 238, 238));

		
		

		
		JLabel lblNewLabel = new JLabel("Spend The Time With Benefit!");
		lblNewLabel.setFont(new Font("Century Gothic", Font.BOLD, 16));
		lblNewLabel.setBounds(191, 96, 247, 16);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel label = new JLabel("Уақытты Тиімді Пайдалану Керек!");
		label.setFont(new Font("Century Gothic", Font.BOLD, 16));
		label.setBounds(173, 112, 265, 29);
		frame.getContentPane().add(label);
		
		JLabel lblNewLabel_1 = new JLabel("GAME");
		lblNewLabel_1.setFont(new Font("Lucida Grande", Font.PLAIN, 27));
		lblNewLabel_1.setBounds(240, 27, 86, 43);
		frame.getContentPane().add(lblNewLabel_1);
		
		JButton btnNewButton = new JButton("Word Search Puzzle");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				puzzlePage puzzle=new puzzlePage();
				puzzle.puzzle();
			}
		});

		
		btnNewButton.setBounds(61, 294, 146, 29);
		frame.getContentPane().add(btnNewButton);	
		
		JButton btnNewButton_1 = new JButton("Fill In The Blank");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				blankPage blank=new blankPage();
				blank.blank();
			}
		});
		btnNewButton_1.setBounds(403, 294, 146, 29);
		frame.getContentPane().add(btnNewButton_1);
		
		JLabel lblNewLabel_2 = new JLabel("");
		Image img1 = new ImageIcon(this.getClass().getResource("/game2.png")).getImage();
		lblNewLabel_2.setIcon(new ImageIcon(img1));
		lblNewLabel_2.setBounds(61, 153, 146, 136);
		frame.getContentPane().add(lblNewLabel_2);
		
		JLabel label_1 = new JLabel("");
		Image img = new ImageIcon(this.getClass().getResource("/fillin.png")).getImage();
		label_1.setIcon(new ImageIcon(img));
		label_1.setBounds(410, 154, 139, 135);
		frame.getContentPane().add(label_1);
		
		JLabel lblNewLabel_3 = new JLabel("");
		Image img5 = new ImageIcon(this.getClass().getResource("/pp.png")).getImage();
		lblNewLabel_3.setIcon(new ImageIcon(img5));
		lblNewLabel_3.setBounds(6, 6, 97, 85);
		frame.getContentPane().add(lblNewLabel_3);
		
		JLabel label12 = new JLabel("");
		Image img2 = new ImageIcon(this.getClass().getResource("/pp.png")).getImage();
		label12.setIcon(new ImageIcon(img2));
		label12.setBounds(6, 315, 97, 85);
		frame.getContentPane().add(label12);
		
		JLabel label_5 = new JLabel("");
		Image img3 = new ImageIcon(this.getClass().getResource("/pp.png")).getImage();
		label_5.setIcon(new ImageIcon(img3));
		label_5.setBounds(519, 315, 75, 85);
		frame.getContentPane().add(label_5);
		
		JLabel label_2 = new JLabel("");
		Image img4 = new ImageIcon(this.getClass().getResource("/pp.png")).getImage();
		label_2.setIcon(new ImageIcon(img4));
		label_2.setBounds(519, 6, 75, 85);
		frame.getContentPane().add(label_2);
		
		JButton btnNewButton_2 = new JButton("Dialogue");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dialog1 dialog1=new dialog1();
				dialog1.dialog1();
				
			}
		});
		btnNewButton_2.setBounds(240, 294, 146, 29);
		frame.getContentPane().add(btnNewButton_2);
		
		JLabel label_3 = new JLabel("");
		Image img6 = new ImageIcon(this.getClass().getResource("/dialogue3.png")).getImage();
		label_3.setIcon(new ImageIcon(img6));
		label_3.setBounds(219, 153, 188, 136);
		frame.getContentPane().add(label_3);
		
		JMenuBar menuBar = new JMenuBar();
		frame.setJMenuBar(menuBar);
		
		JMenu mnNewMenu = new JMenu("File");
		menuBar.add(mnNewMenu);
		
		JMenuItem mntmGame = new JMenuItem("Go to Theory Page");
		mntmGame.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				theoryPage theory=new theoryPage();
				theory.theory();
			}
		});
		mnNewMenu.add(mntmGame);
		JMenuItem mntmHelp = new JMenuItem("Help");
		mntmHelp.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				helpFile help=new helpFile();
				help.help();
			}
		});
		mnNewMenu.add(mntmHelp);
	
		
		JMenuItem mntmNewMenuItem = new JMenuItem("Exit");
		mntmNewMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(JFrame.DISPOSE_ON_CLOSE);
			}
		});
		mnNewMenu.add(mntmNewMenuItem);
	}
}
