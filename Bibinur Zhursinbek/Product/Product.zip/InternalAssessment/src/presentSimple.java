import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Image;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;
import javax.swing.border.Border;

public class presentSimple {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void present() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					presentSimple window = new presentSimple();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public presentSimple() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame("Present Simple");
		frame.setBounds(100, 100, 700, 700);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
	    Object rowData[][] = { { "Row1-Column1", "Row1-Column2", "Row1-Column3" },
	            { "Row2-Column1", "Row2-Column2", "Row2-Column3" } };
	        Object columnNames[] = { "Column One", "Column Two", "Column Three" };
	        JTable table = new JTable(rowData, columnNames);

	 
		
		JTextArea txtrPresentSimpleTense = new JTextArea();
		txtrPresentSimpleTense.setBackground(new Color(175, 238, 238));
		txtrPresentSimpleTense.setWrapStyleWord(true);
		txtrPresentSimpleTense.setLineWrap(true);
		txtrPresentSimpleTense.setText("• Singular form (Жекеше түр)\nAffirmative (Болымды) / Interrogative (Сұрақ) / Negative (Болымсыз)\nI play / Do you play? / I don't play\nYou play / Do I play? / You don't play\nHe plays / Does he play / He doesn't play\nShe plays / Does she play? / She doesn't play\nIt plays / Does it play? / It doesn't play\nЖекеше түрде болымды формада do/does сөйлемде қатыспайды. Бірақ үшінші жақта етістікке -s/-es жалғауы жалғанады.\nCұрақ формада I, you есімдіктерінің алдына do көмекші етістігі, he/she/it есімдіктерінің алдына болса, does көмекші етістігі шығу арқылы жасалады.\nБолымсыз формада болса, do/does көмекші етістіктерінен соң, not шылауы қосылады.\n\n• Plural form (Көпше түр)\nAffirmative (Болымды) / Interrogative (Сұрақ) / Negative (Болымсыз)\nWe play / Do you play? / We do not play\nYou play / Do we play? / You do not play\nThey play / Do they play? / They do not play\nКөпше түрде болымды формада сөйлемдер тек ғана do көмекші етістігінің қатысуымен қолданылады. Болымды формада бірақ do көмекші етістігі сөйлемде қатыспайды. Сұрақ формада do көмекші етістігі есімдіктер алдына шығу арқылы жасалады. Болымсыз формада do көмекші етістігінен соң, not шылауы жалғанады.\n\n• Frequency Adverbs (Уақыт үстеулері):\nAlways 100% Әрқашан\nUsually 99-90% Әдетте\nOften 90-50% Жиі\nSometimes 50-25% Кейде\nSeldom 25-10% Сирек\nRarely 10-1% Өте сирек\nNever 0% Ешқашан\nExamples:\n1) Bolat always comes to class\n2) Maral usually comes to class\n3) We often watch TV at night\n4) I sometimes drink tea with dinner\n5) They seldom go to the movies\n6) Asel rarely makes a mistake\n7) I never eat paper\n\n• Infinitive (Инфинитив)\nInfinitive — дегеніміз to шылауымен жасалушы еш бір жаққа, еш бір шаққа жатпайтын етістік түрі. Мысалы: to work – жұмыс жасау, to study – оқу, үйрену.\nTo шылауы екі етістік қосарласып келгенде қолданылады. Мысалы: I want to play – Мен ойнағым келеді (want етістігімен play етістігінің арасында to қолданылып, to play инфинитив болып тұр.)\n\n• have/has етістігі\nHave етістігі – бар болу, ие болу дегенді білдіреді. Мысалы: I have an apple – Менде алма бар (бір нәрсенің бар екендігін білдіріп тұр).\nHave етістігі 3-жақта he/she/it есімдіктерінен соң has деп қолданылады. Мысалы:\nHe has a ball – Онда доп бар\nHave/has етістігінен соң, көбінесе ауыз-екі тілде got сөзі қосылады. Мысалы:\nI have got a book – Менде кітап бар (got жалғанса да сөйлем мәнісін өзгертпейді)\n\n• have/has жасалуы\nHave / Have got / Translation\nI have a pen / I have got a pen / Менде қалам бар\nYou have a dog / You have got a dog / Сенде ит бар\nHe has a cat / He has got a cat / Онда мысық бар\nWe have books / We have got books / Бізде кітаптар бар\nThey have oxen / They have got oxen / Оларда өгіздер бар\n\n• have/has сұрақ формасы\nHave … Do …\nHave you (got) a pen? Yes, I have (Yes, I’ve) / No, I have not (No, I haven’t)\nDo you have (got) a pen? Yes, I do / No, I do not (No, I don’t)\nHas he (got) a cat? Yes, he has (Yes, he’s) / No, he has not (No, he hasn’t)\nDoes he has (got) a cat? Yes, he does / No, he does not (No, he doesn’t)\nСұрақ форма have/has немесе do/does көмекші етістіктері алдына шығу арқылы жасалады. Бірақ мәнілері өзгермейді. Got сөзін қойсақ та, қоймасақ та болады бәрібір сөйлем өз қалпында қалады.");
		txtrPresentSimpleTense.setBounds(0, 0, 700, 678);
		txtrPresentSimpleTense.setEditable(false);
		frame.getContentPane().add(txtrPresentSimpleTense);
		frame.getContentPane().setBackground(new Color(175, 238, 238));
		JScrollPane scrollPane = new JScrollPane(txtrPresentSimpleTense, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setBounds(6, 6, 98, 80);
		Image img = new ImageIcon(this.getClass().getResource("/pp.png")).getImage();
		lblNewLabel_1.setIcon(new ImageIcon(img));
		frame.getContentPane().add(lblNewLabel_1);
		
		JLabel label = new JLabel("");
		label.setIgnoreRepaint(true);
		label.setBounds(6, 584, 98, 90);
		Image img1 = new ImageIcon(this.getClass().getResource("/pp.png")).getImage();
		label.setIcon(new ImageIcon(img1));
		frame.getContentPane().add(label);
		
		JLabel label_1 = new JLabel("");
		label_1.setBounds(613, 6, 81, 80);
		Image img2 = new ImageIcon(this.getClass().getResource("/pp.png")).getImage();
		label_1.setIcon(new ImageIcon(img2));
		frame.getContentPane().add(label_1);
		
		JLabel label_2 = new JLabel("");
		label_2.setBounds(619, 584, 75, 90);
		Image img3 = new ImageIcon(this.getClass().getResource("/pp.png")).getImage();
		label_2.setIcon(new ImageIcon(img3));
		frame.getContentPane().add(label_2);
		
		 frame.getContentPane().add(scrollPane, BorderLayout.CENTER);
		 scrollPane.setBounds(16, 91, 684, 489);
		frame.getContentPane().add(scrollPane);
		Border emptyBorder = BorderFactory.createEmptyBorder(0, 0, 0, 0);
		scrollPane.setBorder(emptyBorder);
		
		JTextArea txtrPresentSimpleTense_1 = new JTextArea();
		txtrPresentSimpleTense_1.setEditable(false);
		txtrPresentSimpleTense_1.setBackground(new Color(175, 238, 238));
		txtrPresentSimpleTense_1.setWrapStyleWord(true);
		txtrPresentSimpleTense_1.setLineWrap(true);
		txtrPresentSimpleTense_1.setText("\tPresent Simple Tense (Қазіргі осы шақ) – етістігі әдеттегідей, әдетте қайталанып тұрушы белгілі бір уақыт-мезгілді білдірмейтін, жалпы іс-әрекетті білдіреді. Мысалы:\nI live in Almaty – Мен Алматыда тұрамын. (әрдайымғы жасау жері, сондықтан әдеттегі іс-қимыл)\n");
		txtrPresentSimpleTense_1.setBounds(95, 6, 515, 80);
		frame.getContentPane().add(txtrPresentSimpleTense_1);
	}

}
