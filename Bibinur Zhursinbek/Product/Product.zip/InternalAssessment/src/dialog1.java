import java.awt.BorderLayout;
import java.awt.EventQueue;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;
import javax.swing.border.EmptyBorder;
import javax.sound.sampled.AudioFormat;
import javax.sound.sampled.AudioInputStream;
import javax.sound.sampled.AudioSystem;
import javax.sound.sampled.Clip;
import javax.sound.sampled.DataLine;
import javax.sound.sampled.FloatControl;
import javax.sound.sampled.LineUnavailableException;
import javax.sound.sampled.SourceDataLine;
import javax.sound.sampled.UnsupportedAudioFileException;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import sun.audio.*;
import java.io.*;
import java.awt.Color;
import javax.swing.JTextArea;
import java.awt.Font;



public class dialog1 {

	private JFrame frame;
	AudioFormat audioFormat;
	AudioInputStream audioInputStream;
	SourceDataLine sourceDataLine;
	boolean stopPlayback = false;
	private final JButton stopBtn = new JButton("Stop");
	private final JButton playBtn = new JButton("Play");


	/**
	 * Launch the application.
	 */
	public static void dialog1 () {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					dialog1 window = new dialog1();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public dialog1() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame("Dialog");
		frame.getContentPane().setBackground(new Color(175, 238, 238));
		frame.setBounds(100, 100, 700, 700);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		frame.getContentPane().setBackground(new Color(175, 238, 238));
	    playBtn.addActionListener(new ActionListener() {
	    	public void actionPerformed(ActionEvent e) {
	    		  stopBtn.setEnabled(true);
	    	        playBtn.setEnabled(false);
	    	        playAudio();
	    	}
	    });
	    playBtn.setBounds(284, 474, 48, 47);
	    playBtn.setEnabled(true);
	    stopBtn.addActionListener(new ActionListener() {
	    	public void actionPerformed(ActionEvent e) {
	    		  stopPlayback = true;
	    	}
	    });

	   
	    stopBtn.setBounds(334, 474, 48, 47);

	  
	    frame.getContentPane().setLayout(null);

	    frame.getContentPane().add(playBtn);
	    frame.getContentPane().add(stopBtn);
	    JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setBounds(6, 6, 98, 80);
		Image img = new ImageIcon(this.getClass().getResource("/pp.png")).getImage();
		lblNewLabel_1.setIcon(new ImageIcon(img));
		frame.getContentPane().add(lblNewLabel_1);
		
		JLabel label = new JLabel("");
		label.setIgnoreRepaint(true);
		label.setBounds(6, 584, 98, 90);
		Image img1 = new ImageIcon(this.getClass().getResource("/pp.png")).getImage();
		label.setIcon(new ImageIcon(img1));
		frame.getContentPane().add(label);
		
		JLabel label_1 = new JLabel("");
		label_1.setBounds(613, 6, 81, 80);
		Image img2 = new ImageIcon(this.getClass().getResource("/pp.png")).getImage();
		label_1.setIcon(new ImageIcon(img2));
		frame.getContentPane().add(label_1);
		
		JLabel label_2 = new JLabel("");
		label_2.setBounds(619, 584, 75, 90);
		Image img3 = new ImageIcon(this.getClass().getResource("/pp.png")).getImage();
		label_2.setIcon(new ImageIcon(img3));
		frame.getContentPane().add(label_2);
		
		JTextArea txtrhelloHowAre = new JTextArea();
		txtrhelloHowAre.setBackground(new Color(175, 238, 238));
		txtrhelloHowAre.setLineWrap(true);
		txtrhelloHowAre.setWrapStyleWord(true);
		txtrhelloHowAre.setText("-Hello! How are you? (Сәлеметсіз бе! Қалыңыз қалай?)\n\n-Hello! I am good. (Сәлеметсізбе! Жақсымын.)\n \n-Good. How can I help you? (Жақсы. Мен Сізге қалай көмектесе аламын?)\n\n-I booked the table for two people. My name is Maral. (Мен екі адамға үстілді брондап қойдым. Менің атым Марал.)\n\n-Oh, yes. Please, follow me. Would you like to see the menu? (Оу, иә. Менің соңымнан еріңіз. Сізге меню керек пе?)\n \n-Yes, please. There is a wide range of choices. What can you recommend for the drink and main meal? (Иә. Осында өте көп түрлі тағамдар бар. Сіз негізгі тамақтану мен сусынға нені ұсынасыз?)\n \n-Airan is very popular among the drinks. Moreover, a lot of people praise the palau. (Сусындардың ортасында айран өте әйгілі. Одан басқа, өте көп адамдар палауды алады.)\n\n-I think I’d like a chicken salad, palau and coffee. Thank you! (Маған тауық етінен жасалған салат, палау және кофе таңдадым. Рақмет!) \n\n-Meal preparation will take about 15 minutes. Bye! (Тамақ он бес минут ішінде дайындайды. Сау болыңыз!)\n\n");
		txtrhelloHowAre.setBounds(56, 80, 587, 389);
		frame.getContentPane().add(txtrhelloHowAre);
		
		JLabel lblNewLabel = new JLabel("At the restaurant\n");
		lblNewLabel.setFont(new Font("Cooper Black", Font.PLAIN, 24));
		lblNewLabel.setBounds(227, 6, 224, 62);
		frame.getContentPane().add(lblNewLabel);
		
		JLabel lblNewLabel_2 = new JLabel("New label");
		lblNewLabel_2.setBounds(206, 528, 267, 139);
		Image img4 = new ImageIcon(this.getClass().getResource("/res.jpeg")).getImage();
		lblNewLabel_2.setIcon(new ImageIcon(img4));
		frame.getContentPane().add(lblNewLabel_2);
		

	 

		
	}

	private void playAudio()
	{
	    try
	    {
	        File soundFile = new File("/Users/bibinur/Downloads/Dialog1.wav");
	        audioInputStream = AudioSystem.getAudioInputStream(soundFile);
	        audioFormat = audioInputStream.getFormat();
	        System.out.println(audioFormat);
	        DataLine.Info dataLineInfo = new DataLine.Info(SourceDataLine.class,       audioFormat);
	        sourceDataLine = (SourceDataLine)AudioSystem.getLine(dataLineInfo);
	        new PlayThread().start();
	    }

	    catch(Exception e)
	    {
	        e.printStackTrace();
	        System.exit(0);
	    }
	}

	private class PlayThread extends Thread
	{
	    byte tempBuffer[]  = new byte[10000];

	    public void run()
	    {
	        try
	        {
	            sourceDataLine.open(audioFormat);
	            sourceDataLine.start();

	            int cnt;

	            while((cnt = audioInputStream.read(
	                    tempBuffer, 0, tempBuffer.length)) != 1
	                        && stopPlayback == false) 
	            {
	                if(cnt >0)
	                {
	                    sourceDataLine.write(tempBuffer, 0, cnt);
	                }
	            }

	            sourceDataLine.drain();
	            sourceDataLine.close();

	            stopBtn.setEnabled(false);
	            playBtn.setEnabled(true);
	            stopPlayback = false;
	        }

	        catch (Exception e)
	        {
	            e.printStackTrace();
	            System.exit(0);
	                }
	            }
	        }




	
}
