import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Image;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.border.Border;

public class futureSimple {

	private JFrame frame;

	/**
	 * Launch the application.
	 */
	public static void future() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					futureSimple window = new futureSimple();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public futureSimple() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame("Future Simple");
		frame.getContentPane().setBackground(new Color(175, 238, 238));
		frame.setBounds(100, 100, 700, 700);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setBounds(6, 6, 98, 90);
		Image img = new ImageIcon(this.getClass().getResource("/pp.png")).getImage();
		lblNewLabel_1.setIcon(new ImageIcon(img));
		frame.getContentPane().add(lblNewLabel_1);
		
		JLabel label = new JLabel("");
		label.setIgnoreRepaint(true);
		label.setBounds(6, 574, 83, 100);
		Image img1 = new ImageIcon(this.getClass().getResource("/pp.png")).getImage();
		label.setIcon(new ImageIcon(img1));
		frame.getContentPane().add(label);
		
		JLabel label_1 = new JLabel("");
		label_1.setBounds(619, 6, 75, 90);
		Image img2 = new ImageIcon(this.getClass().getResource("/pp.png")).getImage();
		label_1.setIcon(new ImageIcon(img2));
		frame.getContentPane().add(label_1);
		
		JLabel label_2 = new JLabel("");
		label_2.setBounds(619, 584, 75, 90);
		Image img3 = new ImageIcon(this.getClass().getResource("/pp.png")).getImage();
		label_2.setIcon(new ImageIcon(img3));
		frame.getContentPane().add(label_2);
		
		JTextArea txtrTheIndefinite = new JTextArea();
		txtrTheIndefinite.setEditable(false);
		txtrTheIndefinite.setBackground(new Color(175, 238, 238));
		txtrTheIndefinite.setWrapStyleWord(true);
		txtrTheIndefinite.setLineWrap(true);
		txtrTheIndefinite.setText("Ереже! Грамматикалық ережелерге сай бірінші, екінші, үшінші жақтар: you, he/she/it, they «will» көмекші сөзі қолданылады. Мысалы:\nI (or We) will learn English — Мен (немесе біз) ағылшын тілін үйренемін (үйренеміз).\nAskhat will come tomorrow  — Асхат ертең келеді.\nMy grandfather will go to Astana — Менің атам Астанаға барады.\n\nБолымсыз: Your mother will not (wil not=won’t) work on next week — Сенің анаң келесі аптада жұмыс істемейді.\nСұраулы: Will they call us? — Олар бізге телефон соға ма?\n\nАуыспалы осы шақ (Present Simple) арқылы келер шақтағы сөйлемді жасау үшін осы шақ сөйлемінде міндетті түрде келер шаққа қатысты мезгіл үстеуі болу керек. Мысалы:\nWe have an exam on next Friday — Келесі жұмада біздің емтиханымыз бар.\nSayat comes tomorrow — Саят ертең келеді.\nThe bus goes  tonight — Автобус бүгін кешке (түнде) жүреді.\n\nFutere Tense сөйлемдері нақ осы шақ (Present Continuous) арқылы да жасалады. Бірақ сөйлемде келер шақтың мезгіл үстеуі болу керек. Мысалы:\nI am visiting you tomorrow — Мен ертең сізге (саған) қонаққа барамын.\nWhat are you doing on next Sunday? — Келесі жексенбіде не істегелі жатырсыз?\n\n«going to» тіркесі арқылы да келер шақ сөйлемдерін жасауға болады. Оның формуласы мынадай: to be + going to + verb. Мысалы:\nI am going to have a test  — Мен (алдағы уақытта) тест тапсырғалы жатырмын.\nMy brother is going to study Mechanical Engineering — Менің ағам машина жасау мамандығын оқиды. Алдағы уақытта сол мамандыққа түседі.\nAre you going to do this work later? — Сен бұл жұмысты кейінірек жасайсың ба?");
	txtrTheIndefinite.setBounds(0, 0, 700, 678);
		frame.getContentPane().add(txtrTheIndefinite);
		
		JScrollPane scrollPane = new JScrollPane(txtrTheIndefinite, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_NEVER);
		scrollPane.setBounds(10, 124, 690, 459);
		frame.getContentPane().add(scrollPane);
		Border emptyBorder = BorderFactory.createEmptyBorder(0, 0, 0, 0);
		scrollPane.setBorder(emptyBorder);
		
		JTextArea textArea_1 = new JTextArea();
		textArea_1.setEditable(false);
		textArea_1.setBackground(new Color(175, 238, 238));
		textArea_1.setLineWrap(true);
		textArea_1.setWrapStyleWord(true);
		textArea_1.setText("\tКелер шақ арқылы болашақта орындалатын іс-әрекеттер мен жоспарлаған іс-әрекеттерімізді әңгімелей аламыз. Ағылшын тіліндегі келер шақ Future Tense (Future Simple Tense) деп аталады. Оның бірнеше жасалу жолдары бар. Future Tense, әдетте, will көмекші сөздері арқылы жасалады (will+verb).");
		textArea_1.setBounds(93, 6, 514, 115);
		frame.getContentPane().add(textArea_1);
		
		
	}

}
