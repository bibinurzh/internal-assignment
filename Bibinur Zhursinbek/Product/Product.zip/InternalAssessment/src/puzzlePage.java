import java.awt.Color;
import java.awt.EventQueue;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.AdjustmentEvent;
import java.awt.event.AdjustmentListener;

import javax.swing.JFrame;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import java.io.*;
import sun.audio.*;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.JTextArea;
import javax.swing.JEditorPane;
import javax.swing.JTextPane;
import java.awt.Component;
import javax.swing.SwingConstants;
import javax.swing.JScrollBar;
import javax.swing.JScrollPane;
import javax.swing.JList;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;

import java.awt.Font;




public class puzzlePage {
	private JFrame frame;
	JButton btnP = new JButton("P");
	JButton btnA = new JButton("A");

	
	private JTextArea textArea= new JTextArea();
	private JTextArea textArea_1 = new JTextArea();
	private JTextArea textArea_2 = new JTextArea();
	/**
	 * Launch the application.
	 */
	public static void puzzle() {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					puzzlePage window = new puzzlePage();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public puzzlePage() {
		initialize();

	
	}


	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 700, 700);
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		frame.getContentPane().setBackground(new Color(175, 238, 238));
		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setBounds(6, 6, 98, 80);
		Image img = new ImageIcon(this.getClass().getResource("/pp.png")).getImage();
		lblNewLabel_1.setIcon(new ImageIcon(img));
		frame.getContentPane().add(lblNewLabel_1);
		
		JLabel label = new JLabel("");
		label.setIgnoreRepaint(true);
		label.setBounds(6, 584, 98, 90);
		Image img1 = new ImageIcon(this.getClass().getResource("/pp.png")).getImage();
		label.setIcon(new ImageIcon(img1));
		frame.getContentPane().add(label);
		
		JLabel label_1 = new JLabel("");
		label_1.setBounds(613, 6, 81, 80);
		Image img2 = new ImageIcon(this.getClass().getResource("/pp.png")).getImage();
		label_1.setIcon(new ImageIcon(img2));
		frame.getContentPane().add(label_1);
		
		JLabel label_2 = new JLabel("");
		label_2.setBounds(619, 584, 75, 90);
		Image img3 = new ImageIcon(this.getClass().getResource("/pp.png")).getImage();
		label_2.setIcon(new ImageIcon(img3));
		frame.getContentPane().add(label_2);frame.getContentPane().setLayout(null);
		
		JButton btnNewButton = new JButton("A");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Object source = e.getSource();
				if (source==btnNewButton)
				{
					textArea.append("A");
				}
				
			}
		});
		btnNewButton.setBounds(78, 116, 45, 36);
		frame.getContentPane().add(btnNewButton);
		
		JButton btnC = new JButton("C");
		btnC.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Object source = e.getSource();
				if (source==btnC)
				{
					textArea.append("C");
				}
			}
		});
		btnC.setBounds(78, 82, 45, 36);
		frame.getContentPane().add(btnC);
		
		JButton btnE = new JButton("E");
		btnE.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Object source = e.getSource();
				if (source==btnE)
				{
					textArea.append("E");
				}
			}
		});
		btnE.setBounds(164, 82, 45, 36);
		frame.getContentPane().add(btnE);
		
		JButton btnT = new JButton("T");
		btnT.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Object source = e.getSource();
				if (source==btnT)
				{
					textArea.append("T");
				}
			}
		});
		btnT.setBounds(78, 149, 45, 36);
		frame.getContentPane().add(btnT);
		
		JButton btnO = new JButton("O");
		btnO.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Object source = e.getSource();
				if (source==btnO)
				{
					textArea.append("O");
					
				}
			}
		});
		btnO.setBounds(120, 116, 45, 36);
		frame.getContentPane().add(btnO);
		
		JButton btnU = new JButton("U");
		btnU.addActionListener(new ActionListener() {
		public void actionPerformed(ActionEvent e) {
			Object source = e.getSource();
			if (source==btnU)
			{
				textArea.append("U");
			}
		}
		
	});
		btnU.setBounds(164, 116, 45, 36);
		frame.getContentPane().add(btnU);
		
		JButton btnQ = new JButton("Q");
		btnQ.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Object source = e.getSource();
				if (source==btnQ)
				{
					textArea.append("Q");
				}
			}
		});
		btnQ.setBounds(120, 82, 45, 36);
		frame.getContentPane().add(btnQ);
		
		JButton btnE_1 = new JButton("E");
		btnE_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Object source = e.getSource();
				if (source==btnE_1)
				{
					textArea.append("E");
				}
			}
		});
		btnE_1.setBounds(120, 149, 45, 36);
		frame.getContentPane().add(btnE_1);
		
		JButton btnS = new JButton("S");
		btnS.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Object source = e.getSource();
				if (source==btnS)
				{
					textArea.append("S");
				}
			}
		});
		btnS.setBounds(164, 149, 45, 36);
		frame.getContentPane().add(btnS);
		
		
		textArea.setBounds(273, 116, 125, 36);
		frame.getContentPane().add(textArea);
		 textArea_1.setBounds (273, 238, 125, 36);
		 frame.getContentPane().add(textArea_1);
		JButton btnNewButton_1 = new JButton("Submit");
		btnNewButton_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(textArea.getText().equals("cat")||(textArea.getText().equals("CAT")||(textArea.getText().equals("Cat"))))
				{
					JOptionPane.showMessageDialog(null, "Right");
				}
				else {
					JOptionPane.showMessageDialog(null, "Oops. The answer is different.");
				}
			
				
			}
		});
		btnNewButton_1.setBounds(406, 116, 62, 36);
		frame.getContentPane().add(btnNewButton_1);
		
		JButton btnNewButton_2 = new JButton("M");
		btnNewButton_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Object source = e.getSource();
				if (source==btnNewButton_2)
				{
					textArea_1.append("M");
					
				}
			}
		});
		btnNewButton_2.setBounds(78, 197, 45, 36);
		frame.getContentPane().add(btnNewButton_2);
		
		JLabel lblNewLabel = new JLabel("<html>1. It is type of indoor pets that is small, furry, <br> carnivorous mammal. It has strong flexible body, quick reflexes and the ability to hunt on small prey (e.g. mice).</html>");
		lblNewLabel.setBounds(232, 57, 369, 48);
		frame.getContentPane().add(lblNewLabel);
		
		JButton btnI = new JButton("I");
		btnI.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Object source = e.getSource();
				if (source==btnI)
				{
					textArea_1.append("I");
				}
			}
		});
		btnI.setBounds(78, 229, 45, 36);
		frame.getContentPane().add(btnI);
		
		JButton btnA_1 = new JButton("A");
		btnA_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Object source = e.getSource();
				if (source==btnA_1)
				{
					textArea_1.append("A");
					
				}
			}
		});
		btnA_1.setBounds(78, 262, 45, 36);
		frame.getContentPane().add(btnA_1);
		
		JButton btnR = new JButton("R");
		btnR.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Object source = e.getSource();
				if (source==btnR)
				{
					textArea_1.append("R");
				}
			}
		});
		btnR.setBounds(120, 262, 45, 36);
		frame.getContentPane().add(btnR);
		
		JButton btnL_1 = new JButton("L");
		btnL_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Object source = e.getSource();
				if (source==btnL_1)
				{
					textArea_1.append("L");
					
				}
			}
		});
		btnL_1.setBounds(120, 229, 45, 36);
		frame.getContentPane().add(btnL_1);
		
		JButton btnW = new JButton("W");
		btnW.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Object source = e.getSource();
				if (source==btnW)
				{
					textArea_1.append("W");
					
				}
			}
		});
		btnW.setBounds(164, 262, 45, 36);
		frame.getContentPane().add(btnW);
		
		JButton btnF = new JButton("F");
		btnF.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Object source = e.getSource();
				if (source==btnF)
				{
					textArea_1.append("F");
					
				}
			}
		});
		btnF.setBounds(164, 229, 45, 36);
		frame.getContentPane().add(btnF);
		
		JButton btnX = new JButton("X");
		btnX.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Object source = e.getSource();
				if (source==btnX)
				{
					textArea_1.append("X");
					
				}
			}
		});
		btnX.setBounds(164, 197, 45, 36);
		frame.getContentPane().add(btnX);
		
		JButton btnR_1 = new JButton("R");
		btnR_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Object source = e.getSource();
				if (source==btnR_1)
				{
					textArea_1.append("R");
					
				}
			}
		});
		btnR_1.setBounds(120, 197, 45, 36);
		frame.getContentPane().add(btnR_1);
		
		JLabel lblAnAnimalThat = new JLabel("2. An animal that has wings, feather and is able to fly.");
		lblAnAnimalThat.setBounds(232, 180, 358, 58);
		frame.getContentPane().add(lblAnAnimalThat);
		
		JButton button_8 = new JButton("Submit");
		button_8.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(textArea_1.getText().equals("bird")||(textArea_1.getText().equals("BIRD")||(textArea_1.getText().equals("Bird"))))
				{
					JOptionPane.showMessageDialog(null, "Right");
				}
				else {
					JOptionPane.showMessageDialog(null, "Oops. The answer is different.");
				}
			
			}
		});
		button_8.setBounds(406, 238, 62, 36);
		frame.getContentPane().add(button_8);
		
		
		
		
		
		JButton btnB = new JButton("B");
		btnB.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Object source = e.getSource();
				if (source==btnB)
				{
					textArea_1.append("B");
				}
			}
		});
		btnB.setBounds(38, 197, 45, 36);
		frame.getContentPane().add(btnB);
		
		JButton btnE_2 = new JButton("E");
		btnE_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Object source = e.getSource();
				if (source==btnE_2)
				{
					textArea_1.append("E");
					
				}
			}
		});
		btnE_2.setBounds(38, 229, 45, 36);
		frame.getContentPane().add(btnE_2);
		
		JButton btnO_1 = new JButton("O");
		btnO_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Object source = e.getSource();
				if (source==btnO_1)
				{
					textArea_1.append("O");
					
				}
			}
		});
		btnO_1.setBounds(78, 294, 45, 36);
		frame.getContentPane().add(btnO_1);
		
		JButton btnD = new JButton("D");
		btnD.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Object source = e.getSource();
				if (source==btnD)
				{
					textArea_1.append("D");
					
				}
			}
		});
		btnD.setBounds(164, 294, 45, 36);
		frame.getContentPane().add(btnD);
		
		JButton btnR_2 = new JButton("R");
		btnR_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Object source = e.getSource();
				if (source==btnR_2)
				{
					textArea_1.append("R");
					
				}
			}
		});
		btnR_2.setBounds(120, 294, 45, 36);
		frame.getContentPane().add(btnR_2);
		
		JButton btnE_3 = new JButton("E");
		btnE_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Object source = e.getSource();
				if (source==btnE_3)
				{
					textArea_1.append("E");
					
				}
			}
		});
		btnE_3.setBounds(38, 262, 45, 36);
		frame.getContentPane().add(btnE_3);
		
		JButton btnL = new JButton("L");
		btnL.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Object source = e.getSource();
				if (source==btnL)
				{
					textArea_1.append("L");
					
				}
			}
		});
		btnL.setBounds(38, 294, 45, 36);
		frame.getContentPane().add(btnL);
		
		
		
		JButton btnNewButton_3 = new JButton("F");
		btnNewButton_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Object source = e.getSource();
				if (source==btnNewButton_3)
				{
					textArea_2.append("F");
				}
			}
		});
		btnNewButton_3.setBounds(38, 349, 45, 36);
		frame.getContentPane().add(btnNewButton_3);
		
		JButton btnD_2 = new JButton("D");
		btnD_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Object source = e.getSource();
				if (source==btnD_2)
				{
					textArea_2.append("D");
				}
			}
		});
		btnD_2.setBounds(38, 382, 45, 36);
		frame.getContentPane().add(btnD_2);
		
		JButton btnY = new JButton("Y");
		btnY.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Object source = e.getSource();
				if (source==btnY)
				{
					textArea_2.append("Y");
				}
			}
		});
		btnY.setBounds(38, 414, 45, 36);
		frame.getContentPane().add(btnY);
		
		JButton btnR_3 = new JButton("R");
		btnR_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Object source = e.getSource();
				if (source==btnR_3)
				{
					textArea_2.append("R");
				}
			}
		});
		btnR_3.setBounds(38, 448, 45, 36);
		frame.getContentPane().add(btnR_3);
		
		JButton btnA_3 = new JButton("A");
		btnA_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Object source = e.getSource();
				if (source==btnA_3)
				{
					textArea_2.append("A");
				}
			}
		});
		btnA_3.setBounds(38, 481, 45, 36);
		frame.getContentPane().add(btnA_3);
		
		JButton btnO_2 = new JButton("O");
		btnO_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Object source = e.getSource();
				if (source==btnO_2)
				{
					textArea_2.append("O");
				}
			}
		});
		btnO_2.setBounds(78, 382, 45, 36);
		frame.getContentPane().add(btnO_2);
		
		JButton btnK = new JButton("K");
		btnK.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Object source = e.getSource();
				if (source==btnK)
				{
					textArea_2.append("K");
				}
			}
		});
		btnK.setBounds(78, 414, 45, 36);
		frame.getContentPane().add(btnK);
		
		JButton btnI_1 = new JButton("I");
		btnI_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Object source = e.getSource();
				if (source==btnI_1)
				{
					textArea_2.append("I");
				}
			}
		});
		btnI_1.setBounds(78, 349, 45, 36);
		frame.getContentPane().add(btnI_1);
		
		JButton btnX_2 = new JButton("X");
		btnX_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Object source = e.getSource();
				if (source==btnX_2)
				{
					textArea_2.append("X");
				}
			}
		});
		btnX_2.setBounds(120, 349, 45, 36);
		frame.getContentPane().add(btnX_2);
		
		JButton btnD_1 = new JButton("D");
		btnD_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Object source = e.getSource();
				if (source==btnD_1)
				{
					textArea_2.append("D");
				}
			}
			
		});
		btnD_1.setBounds(78, 481, 45, 36);
		frame.getContentPane().add(btnD_1);
		
		JButton btnQ_1 = new JButton("Q");
		btnQ_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Object source = e.getSource();
				if (source==btnQ_1)
				{
					textArea_2.append("Q");
				}
			}
		});
		btnQ_1.setBounds(78, 448, 45, 36);
		frame.getContentPane().add(btnQ_1);
		
		JButton btnN = new JButton("N");
		btnN.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Object source = e.getSource();
				if (source==btnN)
				{
					textArea_2.append("N");
				}
			
			}
		});
		btnN.setBounds(120, 481, 45, 36);
		frame.getContentPane().add(btnN);
		
		JButton btnA_2 = new JButton("A");
		btnA_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Object source = e.getSource();
				if (source==btnA_2)
				{
					textArea_2.append("A");
				}
				
			}
		});
		btnA_2.setBounds(164, 481, 45, 36);
		frame.getContentPane().add(btnA_2);
		
		JButton btnP_1 = new JButton("P");
		btnP_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Object source = e.getSource();
				if (source==btnP_1)
				{
					textArea_2.append("P");
				}
			}
		});
		btnP_1.setBounds(207, 481, 45, 36);
		frame.getContentPane().add(btnP_1);
		
		JButton btnB_1 = new JButton("B");
		btnB_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Object source = e.getSource();
				if (source==btnB_1)
				{
					textArea_2.append("B");
				}
			}
		});
		btnB_1.setBounds(120, 448, 45, 36);
		frame.getContentPane().add(btnB_1);
		
		JButton btnP_2 = new JButton("P");
		btnP_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Object source = e.getSource();
				if (source==btnP_2)
				{
					textArea_2.append("P");
				}
			}
		});
		btnP_2.setBounds(164, 448, 45, 36);
		frame.getContentPane().add(btnP_2);
		
		JButton btnE_4 = new JButton("E");
		btnE_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Object source = e.getSource();
				if (source==btnE_4)
				{
					textArea_2.append("E");
				}
			}
		});
		btnE_4.setBounds(207, 448, 45, 36);
		frame.getContentPane().add(btnE_4);
		
		JButton btnX_1 = new JButton("X");
		btnX_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Object source = e.getSource();
				if (source==btnX_1)
				{
					textArea_2.append("X");
				}
			}
		});
		btnX_1.setBounds(120, 414, 45, 36);
		frame.getContentPane().add(btnX_1);
		
		JButton btnO_3 = new JButton("O");
		btnO_3.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Object source = e.getSource();
				if (source==btnO_3)
				{
					textArea_2.append("O");
				}
			}
		});
		btnO_3.setBounds(164, 414, 45, 36);
		frame.getContentPane().add(btnO_3);
		
		JButton btnN_2 = new JButton("N");
		btnN_2.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Object source = e.getSource();
				if (source==btnN_2)
				{
					textArea_2.append("N");
				}
			}
		
		});
		btnN_2.setBounds(207, 414, 45, 36);
		frame.getContentPane().add(btnN_2);
		
		JButton btnG = new JButton("G");
		btnG.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Object source = e.getSource();
				if (source==btnG)
				{
					textArea_2.append("G");
				}
			}
		});
		btnG.setBounds(120, 382, 45, 36);
		frame.getContentPane().add(btnG);
		
		JButton btnJ = new JButton("J");
		btnJ.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Object source = e.getSource();
				if (source==btnJ)
				{
					textArea_2.append("J");
				}
			}
		});
		btnJ.setBounds(164, 382, 45, 36);
		frame.getContentPane().add(btnJ);
		
		JButton btnA_4 = new JButton("A");
		btnA_4.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Object source = e.getSource();
				if (source==btnA_4)
				{
					textArea_2.append("A");
				}
			}
		});
		btnA_4.setBounds(207, 382, 45, 36);
		frame.getContentPane().add(btnA_4);
		
		JButton btnN_1 = new JButton("N");
		btnN_1.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Object source = e.getSource();
				if (source==btnN_1)
				{
					textArea_2.append("N");
				}
			}
		});
		btnN_1.setBounds(164, 349, 45, 36);
		frame.getContentPane().add(btnN_1);
		
		JButton btnM = new JButton("M");
		btnM.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				Object source = e.getSource();
				if (source==btnM)
				{
					textArea_2.append("M");
				}
			}
		});
		btnM.setBounds(207, 349, 45, 36);
		frame.getContentPane().add(btnM);
		
		JLabel lblALarge = new JLabel("3. A large and gentle mammal that eats bamboo.  ");
		lblALarge.setBounds(273, 327, 358, 58);
		frame.getContentPane().add(lblALarge);
		
		
		textArea_2.setBounds(273, 382, 125, 36);
		frame.getContentPane().add(textArea_2);
		
		JButton button_25 = new JButton("Submit");
		button_25.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				if(textArea_2.getText().equals("panda")||(textArea_2.getText().equals("PANDA")||(textArea_2.getText().equals("Panda"))))
				{
					JOptionPane.showMessageDialog(null, "Right");
				}
				else {
					JOptionPane.showMessageDialog(null, "Oops. The answer is different.");
				}
			}
		});
		button_25.setBounds(406, 382, 62, 36);
		frame.getContentPane().add(button_25);
		
		JLabel lblNewLabel_2 = new JLabel("TRY YOUR BEST!");
		lblNewLabel_2.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_2.setFont(new Font("Stencil", Font.PLAIN, 24));
		lblNewLabel_2.setBounds(207, 561, 309, 48);
		frame.getContentPane().add(lblNewLabel_2);
		JMenuBar menuBar = new JMenuBar();
		frame.setJMenuBar(menuBar);
		JMenu mnNewMenu = new JMenu("File");
		menuBar.add(mnNewMenu);
		JMenuItem mntmGame = new JMenuItem("Go to Theory Page");
		mntmGame.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				theoryPage theory=new theoryPage();
				theory.theory();
			}
		});
		
		mnNewMenu.add(mntmGame);
		
		JMenuItem mntmNewMenuItem = new JMenuItem("Exit");
		mntmNewMenuItem.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(JFrame.EXIT_ON_CLOSE);
			}
		});
		mnNewMenu.add(mntmNewMenuItem);
		frame.getContentPane().setLayout(null);
		
	}
	}
	


	